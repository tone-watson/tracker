#!/usr/bin/env bash
set -euo pipefail
if [[ "$(uname -s)" != Darwin ]]; then
  echo "The native AuthenticationServices addon requires macOS and the Xcode command-line tools." >&2
  exit 1
fi
native_source_dir="$(cd "$(dirname "$0")" && pwd)"
native_output_dir="${1:?Usage: build-macos.sh OUTPUT_DIRECTORY [arm64|x64]}"
case "$native_output_dir" in /*) ;; *) native_output_dir="$PWD/$native_output_dir" ;; esac
native_arch="${2:-arm64}"
case "$native_arch" in arm64|x64) ;; *) echo "Unsupported architecture" >&2; exit 1;; esac
xcrun --sdk macosx --find clang >/dev/null
cd "$native_source_dir"
# Node-API v8 avoids V8 ABI coupling. Do not run this automatically during npm install.
npx --yes node-gyp@11.4.2 rebuild --arch="$native_arch"
mkdir -p "$native_output_dir"
cp build/Release/farm_passkeys.node "$native_output_dir/farm-passkeys.node"
echo "Built $native_output_dir/farm-passkeys.node. Packaging must sign it with the host application."
