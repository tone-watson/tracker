# Native macOS passkeys

This component presents Apple's AuthenticationServices sheet from the Electron main process.
For sign-in, the portal transport is hidden and Apple's sheet attaches to the main app window.
Enrollment and management use a visible app-owned modal. Both use the same native bridge;
no external browser is opened by the desktop transport. Password sign-in remains available.

The JavaScript controller and mock tests run on Linux. The Objective-C++ component must also be
compiled against the macOS SDK and tested in a provisioned, signed Mac application before release.
Source availability and passing mock tests do not establish working Touch ID or Apple Passwords.

## Build the reusable addon

Use macOS with the Xcode command-line tools and Node 22 or later:

```sh
bash node_modules/@noiseflood/auth/native/build-macos.sh "$PWD/build/native" arm64
```

The build pins node-gyp and uses Node-API v8, AppKit, AuthenticationServices and Security.
It targets macOS 13 or later. Package the resulting `farm-passkeys.node` as
`Contents/Resources/native/farm-passkeys.node`, outside app.asar. Build this artifact again when
the native source changes; do not download executable code at application runtime. Keep the
binary associated with the reviewed package version and record its SHA-256 with the release.
There is no native compilation in npm's install lifecycle, so web builds do not need Xcode.

Version 0.4.0 adds Apple's immediately-available-credentials request option and
exports `supportsImmediatelyAvailableCredentials()`. Recompile once when adopting
that version; an older binary safely skips automatic sign-in instead of displaying
an unexpected nearby-device QR prompt. Existing profiles and certificates remain valid.

The existing `farm build electron` command on the farm packages the downloaded macOS Electron
runtime with electron-builder, then signs/notarizes using rcodesign. That workflow can consume
this compiled addon. It does not itself compile the Apple-framework source. A macOS SDK/compiler
build step or a separately supplied reviewed native artifact is required.

The addon has no app-specific identity embedded in it: compile once per source version and
architecture, then reuse that exact file for all four apps. After transferring the compiled file
to `/tmp/farm-passkeys-artifact/farm-passkeys.node` on the farm, copy it into the four build inputs:

```sh
for passkey_app_root in /srv/farm/code/morph /srv/farm/code/flooder /srv/farm/sys/manager/desktop /srv/farm/sys/floodgate; do
  install -d "$passkey_app_root/build/native"
  install -m 644 /tmp/farm-passkeys-artifact/farm-passkeys.node "$passkey_app_root/build/native/farm-passkeys.node"
done
sha256sum /tmp/farm-passkeys-artifact/farm-passkeys.node
```

Supply each app's own profile separately; those files are not interchangeable. This preparation
does not invoke `farm build electron`, because that command also publishes releases.

## Configure each host application's identity

Enable Associated Domains on each explicit App ID in the Apple Developer account.
Create/download an appropriate Developer ID distribution provisioning profile that authorizes
that capability, the signing certificate and the app identifier. Development testing needs its
corresponding development profile and signing identity. Use the exact macOS bundle IDs below.

| Application | Bundle ID |
| --- | --- |
| Morph | `farm.noiseflood.morph.desktop` |
| Flooder | `com.flooder.app` |
| Manager | `farm.noiseflood.manager.desktop` |
| Floodgate | `farm.noiseflood.floodgate.desktop` |

Morph's new explicit App ID was registered under team `K6RC68T8Z3` on 2026-09-18
after Apple rejected registration of its previous `com.morph.app` identifier.
Its `build.mac.appId` overrides the global `build.appId`, preserving the existing
Windows/Linux identity. The app name, data directory and authentication client ID
remain unchanged. This migration requires a one-time manual replacement of `Morph.app`:
[Squirrel.Mac requires matching bundle identifiers](https://github.com/Squirrel/Squirrel.Mac/blob/master/Squirrel/SQRLUpdater.m)
for automatic updates. Before release, test that replacement from the previously signed
Mac version, including saved login and macOS permissions, then test automatic updates
between builds using the new identifier. Do not delete user data.
The reusable native addon does not need recompilation for this identifier change.

The root application needs these signed entitlements:

```xml
<key>com.apple.developer.associated-domains</key>
<array><string>webcredentials:noiseflood.farm</string></array>
<key>com.apple.application-identifier</key>
<string>APP_IDENTIFIER_PREFIX.BUNDLE_ID</string>
<key>com.apple.developer.team-identifier</key>
<string>TEAM_ID</string>
```

The existing team is `K6RC68T8Z3`; confirm the identifier prefix against the actual profile.
Place the profile at the app repository's `build/embedded.provisionprofile` and copy it to
`Contents/embedded.provisionprofile` before final signing. Profiles are machine configuration,
not placeholders to generate or commit. A plist entitlement alone does not authorize the app.

Electron helper executables use their separate existing inherited entitlements. Do not apply the
main application's identifier or associated-domain capability to the helpers. Sign the native
addon as nested code with the host app's signing identity, then sign/notarize the finished bundle.

electron-builder configuration needs:

- Root `mac.entitlements`: `build/entitlements.mac.plist`.
- `mac.entitlementsInherit`: `build/entitlements.mac.inherit.plist`.
- The native binary copied to `native/farm-passkeys.node` using `mac.extraResources`.
- The provisioning profile embedded before the final signing step.

The shared farm release script must respect the separate inherited plist and profile. Its current
Linux rcodesign path signs root and helpers explicitly, so changing electron-builder alone is not
sufficient. Check native artifacts and profiles before publishing web or desktop release files.

## Associate the identity domain

Deploy `https://noiseflood.farm/.well-known/apple-app-site-association` as public JSON over HTTPS
without authentication or redirects. Its `webcredentials.apps` entries must match the signed app
identifiers. `apple-app-site-association.example.json` gives the current configured team/bundle
mapping; verify it against the generated profiles before deploying. Preserve unrelated existing
association services if the file already exists.

Apple caches domain associations. Verify the association on the test Mac after installing the
signed build; publication alone does not prove the machine has refreshed its association.
Do not broaden the RP ID or server expected origin to bypass a signing/association failure.

## Verification before release

Run the JavaScript tests using `node test/native-electron.cjs` from the package directory.
They exercise strict modal/frame identity, options, PKCE completion, cancellation, deadlines and
missing native support with fake windows and credentials; they never use real credentials.

On the Mac, inspect root/helper entitlements, embedded profile and addon signature. Test enrollment,
fresh sign-in, Touch ID cancellation, no matching key, unavailable iCloud/credential provider,
window close, offline service, and sign-out/account switching in each app. Confirm that a passkey
enrolled for `noiseflood.farm` works through another associated application and Safari. Verify
ordinary password login still works when native support is absent. Never label mock tests as a
biometric/device test.

Native enrollment fails explicitly if an older macOS version cannot honor the server's credential
exclusion list. Update macOS in that case; do not silently overwrite an existing passkey.

References:

- [Apple AuthenticationServices](https://developer.apple.com/documentation/authenticationservices/asauthorizationcontroller)
- [Apple associated domains](https://developer.apple.com/documentation/xcode/supporting-associated-domains)
- [Apple provisioning profiles](https://developer.apple.com/documentation/technotes/tn3125-inside-code-signing-provisioning-profiles)
- [Electron native integration](https://www.electronjs.org/docs/latest/tutorial/native-code-and-electron-swift-macos)
- [Node-API stability](https://nodejs.org/api/n-api.html)
