{
    "targets": [
        {
            "target_name": "farm_passkeys",
            "sources": ["passkeys.mm"],
            "conditions": [
                [
                    "OS=='mac'",
                    {
                        "xcode_settings": {
                            "MACOSX_DEPLOYMENT_TARGET": "13.0",
                            "CLANG_ENABLE_OBJC_ARC": "YES",
                            "CLANG_CXX_LANGUAGE_STANDARD": "c++17",
                            "OTHER_CFLAGS": ["-fobjc-arc"],
                        },
                        "link_settings": {
                            "libraries": [
                                "-framework AppKit",
                                "-framework AuthenticationServices",
                                "-framework Security",
                            ]
                        },
                    },
                ]
            ],
        }
    ]
}
