// Main-process-only Node-API bridge. Build on macOS; see docs/BUILD.md.
#define NAPI_VERSION 8
#include <node_api.h>
#import <AppKit/AppKit.h>
#import <AuthenticationServices/AuthenticationServices.h>
#import <Security/SecTask.h>
#include <cstring>
#include <string>

struct Completion { napi_deferred deferred; napi_threadsafe_function function; };
struct Result { std::string json; std::string code; };
static bool shuttingDown = false;

static NSString *Base64URL(NSData *data) {
  if (!data) return nil;
  return [[[data base64EncodedStringWithOptions:0] stringByReplacingOccurrencesOfString:@"+" withString:@"-"] stringByReplacingOccurrencesOfString:@"/" withString:@"_"];
}
static NSString *Encoded(NSData *data) {
  return [Base64URL(data) stringByReplacingOccurrencesOfString:@"=" withString:@""];
}
static NSData *Decoded(NSString *value) {
  if (![value isKindOfClass:NSString.class]) return nil;
  NSMutableString *text = [[value stringByReplacingOccurrencesOfString:@"-" withString:@"+"] mutableCopy];
  [text replaceOccurrencesOfString:@"_" withString:@"/" options:0 range:NSMakeRange(0, text.length)];
  while (text.length % 4) [text appendString:@"="];
  return [[NSData alloc] initWithBase64EncodedString:text options:0];
}
static napi_value Fail(napi_env env, const char *code) {
  napi_value message, error, codeValue;
  napi_create_string_utf8(env, "The native passkey request could not be completed.", NAPI_AUTO_LENGTH, &message);
  napi_create_error(env, nullptr, message, &error);
  napi_create_string_utf8(env, code, NAPI_AUTO_LENGTH, &codeValue);
  napi_set_named_property(env, error, "code", codeValue);
  napi_throw(env, error);
  return nullptr;
}
static void Deliver(napi_env env, napi_value, void *context, void *data) {
  auto *completion = static_cast<Completion *>(context);
  auto *result = static_cast<Result *>(data);
  if (env && result) {
    napi_value value;
    if (!result->code.empty()) {
      napi_value message, code;
      napi_create_string_utf8(env, "The native passkey request could not be completed.", NAPI_AUTO_LENGTH, &message);
      napi_create_error(env, nullptr, message, &value);
      napi_create_string_utf8(env, result->code.c_str(), NAPI_AUTO_LENGTH, &code);
      napi_set_named_property(env, value, "code", code);
      napi_reject_deferred(env, completion->deferred, value);
    } else {
      napi_value global, json, parse, text;
      napi_get_global(env, &global);
      napi_get_named_property(env, global, "JSON", &json);
      napi_get_named_property(env, json, "parse", &parse);
      napi_create_string_utf8(env, result->json.c_str(), result->json.size(), &text);
      if (napi_call_function(env, json, parse, 1, &text, &value) == napi_ok) napi_resolve_deferred(env, completion->deferred, value);
      else {
        napi_get_and_clear_last_exception(env, &value);
        napi_reject_deferred(env, completion->deferred, value);
      }
    }
  }
  delete result;
}
static void ReleaseCompletion(napi_env, void *data, void *) { delete static_cast<Completion *>(data); }

API_AVAILABLE(macos(13.0))
@interface FarmPasskeyRequest : NSObject <ASAuthorizationControllerDelegate, ASAuthorizationControllerPresentationContextProviding>
@property(nonatomic, strong) ASAuthorizationController *controller;
@property(nonatomic, strong) NSWindow *window;
@property(nonatomic, assign) Completion *completion;
@property(nonatomic, assign) BOOL completed;
- (void)finish:(NSDictionary *)credential code:(NSString *)code;
@end
static FarmPasskeyRequest *activeRequest API_AVAILABLE(macos(13.0));

@implementation FarmPasskeyRequest
- (ASPresentationAnchor)presentationAnchorForAuthorizationController:(ASAuthorizationController *)controller { return self.window; }
- (void)finish:(NSDictionary *)credential code:(NSString *)code {
  if (self.completed) return;
  self.completed = YES;
  Completion *completion = self.completion;
  self.completion = nullptr;
  self.controller.delegate = nil;
  self.controller.presentationContextProvider = nil;
  self.controller = nil;
  self.window = nil;
  if (completion) {
    auto *result = new Result;
    if (code) result->code = code.UTF8String;
    else {
      NSData *json = [NSJSONSerialization dataWithJSONObject:credential options:0 error:nil];
      if (json) result->json.assign(static_cast<const char *>(json.bytes), json.length);
      else result->code = "PASSKEY_FAILED";
    }
    if (shuttingDown || napi_call_threadsafe_function(completion->function, result, napi_tsfn_nonblocking) != napi_ok) delete result;
    napi_release_threadsafe_function(completion->function, shuttingDown ? napi_tsfn_abort : napi_tsfn_release);
  }
  if (activeRequest == self) activeRequest = nil;
}
- (void)authorizationController:(ASAuthorizationController *)controller didCompleteWithError:(NSError *)error {
  [self finish:nil code:([error.domain isEqualToString:ASAuthorizationErrorDomain] && error.code == ASAuthorizationErrorCanceled) ? @"PASSKEY_CANCELLED" : @"PASSKEY_FAILED"];
}
- (void)authorizationController:(ASAuthorizationController *)controller didCompleteWithAuthorization:(ASAuthorization *)authorization {
  NSDictionary *response;
  NSData *identifier;
  if ([authorization.credential isKindOfClass:ASAuthorizationPlatformPublicKeyCredentialAssertion.class]) {
    ASAuthorizationPlatformPublicKeyCredentialAssertion *assertion = (id)authorization.credential;
    identifier = assertion.credentialID;
    if (!identifier.length || !assertion.rawClientDataJSON.length || !assertion.rawAuthenticatorData.length || !assertion.signature.length || !assertion.userID.length) { [self finish:nil code:@"PASSKEY_FAILED"]; return; }
    response = @{ @"clientDataJSON": Encoded(assertion.rawClientDataJSON), @"authenticatorData": Encoded(assertion.rawAuthenticatorData), @"signature": Encoded(assertion.signature), @"userHandle": Encoded(assertion.userID) };
  } else if ([authorization.credential isKindOfClass:ASAuthorizationPlatformPublicKeyCredentialRegistration.class]) {
    ASAuthorizationPlatformPublicKeyCredentialRegistration *registration = (id)authorization.credential;
    identifier = registration.credentialID;
    if (!identifier.length || !registration.rawClientDataJSON.length || !registration.rawAttestationObject.length) { [self finish:nil code:@"PASSKEY_FAILED"]; return; }
    response = @{ @"clientDataJSON": Encoded(registration.rawClientDataJSON), @"attestationObject": Encoded(registration.rawAttestationObject) };
  } else { [self finish:nil code:@"PASSKEY_FAILED"]; return; }
  [self finish:@{ @"id": Encoded(identifier), @"rawId": Encoded(identifier), @"type": @"public-key", @"authenticatorAttachment": @"platform", @"clientExtensionResults": @{}, @"response": response } code:nil];
}
@end

static bool Available() {
  if (@available(macOS 13.0, *)) {
    SecTaskRef task = SecTaskCreateFromSelf(kCFAllocatorDefault);
    if (!task) return false;
    id domains = CFBridgingRelease(SecTaskCopyValueForEntitlement(task, CFSTR("com.apple.developer.associated-domains"), nullptr));
    id identifier = CFBridgingRelease(SecTaskCopyValueForEntitlement(task, CFSTR("com.apple.application-identifier"), nullptr));
    CFRelease(task);
    NSURL *profile = [[NSBundle mainBundle].bundleURL URLByAppendingPathComponent:@"Contents/embedded.provisionprofile"];
    return [domains isKindOfClass:NSArray.class] && [domains containsObject:@"webcredentials:noiseflood.farm"] &&
      [identifier isKindOfClass:NSString.class] && [identifier length] > 0 && [[NSFileManager defaultManager] fileExistsAtPath:profile.path];
  }
  return false;
}
static napi_value IsAvailable(napi_env env, napi_callback_info) { napi_value value; napi_get_boolean(env, Available(), &value); return value; }
static bool SupportsImmediatelyAvailableCredentials() {
  if (@available(macOS 13.0, *)) return [ASAuthorizationController instancesRespondToSelector:@selector(performRequestsWithOptions:)];
  return false;
}
static napi_value SupportsImmediatelyAvailable(napi_env env, napi_callback_info) { napi_value value; napi_get_boolean(env, SupportsImmediatelyAvailableCredentials(), &value); return value; }

static NSDictionary *Options(napi_env env, napi_value input) {
  napi_value global, json, stringify, text;
  napi_get_global(env, &global);
  napi_get_named_property(env, global, "JSON", &json);
  napi_get_named_property(env, json, "stringify", &stringify);
  if (napi_call_function(env, json, stringify, 1, &input, &text) != napi_ok) return nil;
  size_t length = 0;
  if (napi_get_value_string_utf8(env, text, nullptr, 0, &length) != napi_ok || length > 32768) return nil;
  std::string buffer(length + 1, '\0');
  napi_get_value_string_utf8(env, text, buffer.data(), buffer.size(), &length);
  id value = [NSJSONSerialization JSONObjectWithData:[NSData dataWithBytes:buffer.data() length:length] options:0 error:nil];
  return [value isKindOfClass:NSDictionary.class] ? value : nil;
}
static napi_value Request(napi_env env, napi_callback_info info, bool registration) {
  if (!Available()) return Fail(env, "PASSKEY_UNSUPPORTED");
  if (![NSThread isMainThread]) return Fail(env, "PASSKEY_FAILED");
  if (@available(macOS 13.0, *)) {
    if (activeRequest) return Fail(env, "SESSION_CHANGED");
    size_t count = 1, size = 0; napi_value input, handle; void *bytes = nullptr;
    napi_get_cb_info(env, info, &count, &input, nullptr, nullptr);
    if (count != 1 || napi_get_named_property(env, input, "windowHandle", &handle) != napi_ok || napi_get_buffer_info(env, handle, &bytes, &size) != napi_ok || size != sizeof(void *)) return Fail(env, "INVALID_RESPONSE");
    void *pointer = nullptr; std::memcpy(&pointer, bytes, size);
    NSView *view = (__bridge NSView *)pointer;
    NSWindow *window = view.window;
    if (!window || ![NSApp.windows containsObject:window]) return Fail(env, "SESSION_CHANGED");
    NSDictionary *options = Options(env, input);
    id immediateOption = options[@"preferImmediatelyAvailableCredentials"];
    if (immediateOption && CFGetTypeID((__bridge CFTypeRef)immediateOption) != CFBooleanGetTypeID()) return Fail(env, "INVALID_RESPONSE");
    bool immediate = [immediateOption boolValue];
    if (immediate && registration) return Fail(env, "INVALID_RESPONSE");
    if (immediate && !SupportsImmediatelyAvailableCredentials()) return Fail(env, "PASSKEY_UNSUPPORTED");
    NSString *rp = registration ? options[@"rp"][@"id"] : options[@"rpId"];
    NSData *challenge = Decoded(options[@"challenge"]);
    if (![rp isEqualToString:@"noiseflood.farm"] || challenge.length < 16 || challenge.length > 384) return Fail(env, "INVALID_RESPONSE");
    ASAuthorizationPlatformPublicKeyCredentialProvider *provider = [[ASAuthorizationPlatformPublicKeyCredentialProvider alloc] initWithRelyingPartyIdentifier:rp];
    ASAuthorizationRequest *request;
    if (registration) {
      NSData *userID = Decoded(options[@"user"][@"id"]);
      NSString *name = options[@"user"][@"name"];
      if (!userID.length || userID.length > 64 || ![name isKindOfClass:NSString.class] || !name.length) return Fail(env, "INVALID_RESPONSE");
      ASAuthorizationPlatformPublicKeyCredentialRegistrationRequest *creation = [provider createCredentialRegistrationRequestWithChallenge:challenge name:name userID:userID];
      creation.userVerificationPreference = ASAuthorizationPublicKeyCredentialUserVerificationPreferenceRequired;
      creation.attestationPreference = ASAuthorizationPublicKeyCredentialAttestationKindNone;
      // Fail explicitly if this OS cannot honor exclusion; never replace a key silently.
      NSArray *excluded = options[@"excludeCredentials"];
      if (excluded.count) {
        if (![creation respondsToSelector:NSSelectorFromString(@"setExcludedCredentials:")]) return Fail(env, "PASSKEY_UNSUPPORTED");
        NSMutableArray *descriptors = [NSMutableArray array];
        for (NSDictionary *item in excluded) { NSData *identifier = Decoded(item[@"id"]); if (!identifier.length) return Fail(env, "INVALID_RESPONSE"); [descriptors addObject:[[ASAuthorizationPlatformPublicKeyCredentialDescriptor alloc] initWithCredentialID:identifier]]; }
        [creation setValue:descriptors forKey:@"excludedCredentials"];
      }
      request = creation;
    } else {
      ASAuthorizationPlatformPublicKeyCredentialAssertionRequest *assertion = [provider createCredentialAssertionRequestWithChallenge:challenge];
      assertion.userVerificationPreference = ASAuthorizationPublicKeyCredentialUserVerificationPreferenceRequired;
      NSMutableArray *descriptors = [NSMutableArray array];
      for (NSDictionary *item in options[@"allowCredentials"]) { NSData *identifier = Decoded(item[@"id"]); if (!identifier.length) return Fail(env, "INVALID_RESPONSE"); [descriptors addObject:[[ASAuthorizationPlatformPublicKeyCredentialDescriptor alloc] initWithCredentialID:identifier]]; }
      if (descriptors.count) assertion.allowedCredentials = descriptors;
      request = assertion;
    }
    napi_value promise, resource;
    auto *completion = new Completion;
    napi_create_promise(env, &completion->deferred, &promise);
    napi_create_string_utf8(env, "FarmPasskey", NAPI_AUTO_LENGTH, &resource);
    if (napi_create_threadsafe_function(env, nullptr, nullptr, resource, 1, 1, completion, ReleaseCompletion, completion, Deliver, &completion->function) != napi_ok) { delete completion; return Fail(env, "PASSKEY_FAILED"); }
    napi_unref_threadsafe_function(env, completion->function);
    FarmPasskeyRequest *delegate = [FarmPasskeyRequest new];
    delegate.window = window;
    delegate.completion = completion;
    delegate.controller = [[ASAuthorizationController alloc] initWithAuthorizationRequests:@[request]];
    delegate.controller.delegate = delegate;
    delegate.controller.presentationContextProvider = delegate;
    activeRequest = delegate;
    @try {
      if (immediate) [delegate.controller performRequestsWithOptions:ASAuthorizationControllerRequestOptionPreferImmediatelyAvailableCredentials];
      else [delegate.controller performRequests];
    }
    @catch (NSException *exception) { [delegate finish:nil code:@"PASSKEY_FAILED"]; }
    return promise;
  }
  return Fail(env, "PASSKEY_UNSUPPORTED");
}
static napi_value Assertion(napi_env env, napi_callback_info info) { return Request(env, info, false); }
static napi_value Registration(napi_env env, napi_callback_info info) { return Request(env, info, true); }
static void CancelRequest() {
  if (@available(macOS 13.0, *)) {
    FarmPasskeyRequest *request = activeRequest;
    if (request) { [request.controller cancel]; [request finish:nil code:@"PASSKEY_CANCELLED"]; }
  }
}
static napi_value Cancel(napi_env env, napi_callback_info) { CancelRequest(); napi_value value; napi_get_undefined(env, &value); return value; }
static void Cleanup(void *) { shuttingDown = true; CancelRequest(); }
static napi_value Init(napi_env env, napi_value exports) {
  napi_property_descriptor methods[] = {
    {"isAvailable", nullptr, IsAvailable, nullptr, nullptr, nullptr, napi_default, nullptr},
    {"supportsImmediatelyAvailableCredentials", nullptr, SupportsImmediatelyAvailable, nullptr, nullptr, nullptr, napi_default, nullptr},
    {"requestAssertion", nullptr, Assertion, nullptr, nullptr, nullptr, napi_default, nullptr},
    {"requestRegistration", nullptr, Registration, nullptr, nullptr, nullptr, napi_default, nullptr},
    {"cancel", nullptr, Cancel, nullptr, nullptr, nullptr, napi_default, nullptr}
  };
  napi_define_properties(env, exports, 5, methods);
  napi_add_env_cleanup_hook(env, Cleanup, nullptr);
  return exports;
}
NAPI_MODULE(NODE_GYP_MODULE_NAME, Init)
