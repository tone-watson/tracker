# @noiseflood/auth

Shared, headless authentication client for Farm browser and Electron apps.
ES modules with TypeScript declarations and no runtime dependencies. UI, styling,
routing, and secure platform storage belong to the consuming app.

```js
import { createAuthClient } from '@noiseflood/auth'

const auth = createAuthClient({
  baseURL: 'https://noiseflood.farm/v1',
  mode: 'cookie',
})

const unsubscribe = auth.subscribe(state => {
  // Render state.user using your own components and styles.
})

await auth.initialize() // Checks the server, including existing HttpOnly cookies.
await auth.login(email, password)
const result = await auth.request('app/morph/session')
await auth.logout() // Rejects if the server could not revoke the session.

unsubscribe()
auth.dispose()
```

`request()` returns the API's complete JSON response envelope. `login()` and
`getCurrentUser()` return user data without token fields. `getState()` and
`subscribe()` expose server-verified state. `refresh()` coalesces concurrent
callers. `clearSession()` only clears client state/store and is **not** a
substitute for server logout.

For Electron, select `mode: 'bearer'` and inject a store:

```js
const auth = createAuthClient({
  baseURL: 'https://noiseflood.farm/v1',
  mode: 'bearer',
  tokenStore: {
    load: () => secureStore.load(),
    save: pair => secureStore.save(pair),
    clear: () => secureStore.clear(),
  },
})
```

Legacy stores handle `{ access_token, refresh_token }` asynchronously. They must use
encrypted main-process storage through validated IPC. Never use localStorage or
plaintext files. Morph surfaces secure-store failure as a login error. The package
does not import Electron or control an OS keychain. Store failures are errors
unless the app explicitly implements memory-only behavior.

Use relative API paths. External URLs and path traversal are rejected. HTTPS is
required except for localhost development. Requests do not follow redirects and
do not automatically retry network failures, server failures or rotating refresh
operations. Authentication and explicit CSRF rejection can each cause one
bounded recovery attempt. Pass `signal` for cancellation and `timeoutMs` to
configure the default request timeout. `AuthError` includes `status`, `code` and
`retryAfter`; avoid inferring authentication failure from message text.

Servers with an access-only session protocol can explicitly set `refresh: false`.
On a protected 401, the client then clears its verified state without calling a
refresh endpoint. `refresh()` rejects with `REFRESH_UNSUPPORTED`. The default
remains `true`. Manager uses this mode to preserve its existing session protocol.

`csrf: false` disables token endpoints only for a server that enforces another
CSRF defense. Manager validates browser Origins and Fetch Metadata while keeping
its existing native-client protocol. Never disable CSRF just because cookies use
SameSite. Morph and Flooder retain the default CSRF-token protocol.

`request(path, { timeoutMs })` overrides the timeout for individual long-running
requests. No timeout or network failure is replayed by the shared client.
Both flat Farm errors and nested `{ error: { code, message } }` errors are
preserved as `AuthError` values.

## Native service access (0.5.0)

The additive `@noiseflood/auth/services` entry point implements the
[`farm.service-access/1` wire contract](../../docs/security/service-access-v1.md).
The 0.5.0 archive includes service access, durable refresh journals and explicit
passkey binding negotiation. The earlier 0.4.0 archives remain immutable. Update
the intended consumer's archive and lockfile together; npm cannot update an
installed desktop binary. The native macOS bridge ABI is unchanged by 0.5.0.

Use a central **bearer** client backed by protected platform storage. Setting
`clientId: 'boarders'` on `createAuthClient` includes that registered ID in password
login; Farm requires an administrator-approved client/user grant. Existing native
sessions can transition without another password:

```js
const auth = createAuthClient({
  baseURL: 'https://noiseflood.farm/v1',
  mode: 'bearer',
  clientId: 'boarders',
  tokenStore: {
    supportsSessionJournal: true,
    load: () => secureStore.load(),
    // Atomically and durably replace the WHOLE protected record below.
    save: record => secureStore.save(record),
    clear: () => secureStore.clear(),
  },
})
await auth.initialize()
// This transition requires an authenticated account and an exact registered callback.
if (!auth.getSessionContext().appSessionId) {
  await auth.bindAppSession({
    clientId: 'boarders',
    redirectUri: 'boarders://auth/callback',
  })
}

import { createServiceClient } from '@noiseflood/auth/services'
const services = createServiceClient({
  auth,
  issuer: 'https://noiseflood.farm',
})
const manager = await services.connect('manager', { scopes: ['episodes.read'] })
const episodes = await manager.request('api/episodes')
manager.assertCurrent()
// Also check the caller's original document ID before applying a result to the UI.
```

Binding generates fresh S256 PKCE and state, validates the authorization reply,
exchanges its code once, and atomically stores the returned pair before changing
the account state. It waits for central restoration/rotation; logout waits for a
pending binding to finish so it revokes the final credential. The transition
does not grant permissions or silently change a previously bound client.
Cookie-mode use returns `app_session_binding_required`. Browser backends own
isolated host-only cookie sessions, using this bearer provider and an encrypted
durable store on the server. They authenticate their registered `browser_bff`
client using the private `X-Farm-Client-Credential` header on login, refresh and
code binding/exchange. Only their fixed-destination server transport may add that
header; never expose it to browser/renderer code. The historical `X-Client-Type`
header only selects transport and does not authenticate an application.

Passkey exchange opts into `X-Farm-Session-Binding: farm.service-access/1` only
when this client has a configured `clientId` and journal-capable store. The
handoff's client must match. Old clients stay unbound after policy registration;
registering an app no longer silently changes its stored credential format.
Browser passkey popups support `manager-web` and `floodgate-web` in addition to
the existing app IDs; their exchanges are owned by the confidential backend.

`discover()` returns trusted service metadata and independent access states.
Connections pin the issuer, account, family, session generation, service audience,
destination and sorted scope set. A connection never follows a caller-supplied
server address. Credentials are opaque, memory-only, and coalesced by that entire
identity; they never appear on a connection object or in protected refresh storage.
Renewal rechecks current discovery and rejects a changed destination with
`SERVICE_CHANGED`. Recreate the connection deliberately for that destination.
Discovery is cached for 60 seconds; credentials renew when less than 30 seconds
remain, and their lifetime never exceeds the server's 300 seconds.

Only GET and HEAD retry once after explicit `401 invalid_token`. Mutations,
uploads, transport failures, `403`, `429`, and server errors are never replayed.
Callers own reconciliation after an ambiguous write, request IDs, immutable
publication bytes/hashes, and rebuilding any explicitly retried body. A Manager
denial or outage never clears the Farm account. Direct Farm generation continues
through `auth.request()` independently of Manager.

Requests disable cookies and redirects, sanitize credential headers and refuse
absolute or traversing paths. `responseType` supports `json` (default), `text`,
`arrayBuffer`, and `blob`; each response is fully buffered, with its session
checked again after body completion. Streaming/raw responses are intentionally
not exposed by this provider. Native media integration needing disk streaming
must implement the same cancellation and destination checks in its transport.
Pass an AbortSignal to cancel one caller without canceling another caller's
coalesced acquisition. Disposal or a generation change aborts active work and
prevents late results from becoming usable.

The application must pin its own document/job identity and check it together
with `connection.assertCurrent()` immediately before committing asynchronous
results. Successful logout invalidates every connection without deleting local
documents. Failed logout retains protected central credentials for retry while
invalidating already-running work; create a fresh connection to continue. Do not
derive new storage directories from the connection's issuer or canonical URL:
existing account/document namespaces remain the consuming app's responsibility.

Bound sessions require an explicit protected-store capability,
`supportsSessionJournal: true`. Before setting it, update the adapter to atomically
and durably replace the complete record: `access_token`, `refresh_token`, optional
`app_session` metadata (`id`, `client_id`, optional `expires_at`), and optional
`refresh_pending: true`. A completed replacement removes the pending flag. Do not
whitelist only the two token strings, merge old fields into a new record, or
write tokens and metadata in separate operations. The client checks the store's
capability before accepting bound credentials, then verifies metadata through a
save/load round trip. Keep one auth client responsible for each protected record;
independent native apps must have separate app sessions and stores. Legacy unbound
adapters can keep their existing two-field protocol.

Before sending a bound refresh, the client durably marks the existing pair as
pending. A successful complete replacement atomically clears it. A definite
preadmission 429 clears it while preserving Retry-After behavior. Network loss,
5xx, or interrupted persistence keeps it. On relaunch, a pending record causes
`SESSION_REAUTHENTICATION_REQUIRED` before any refresh request; the client cannot
blindly resend a consumed credential. New central requests/restoration also block
while renewal is uncertain, and `getState().error` explains reauthentication while
the current process retains its existing account metadata. Logout still has the
protected pair to revoke the family. Ordinary sign-in can replace the uncertain
record. Already issued service credentials remain subject to their bounded expiry.
Use `refresh()` rather than a raw request to `auth/refresh` for bound sessions.

`AuthError.requestId` preserves the server's safe request ID for support, alongside
code, status and Retry-After.

Passkey support is optional and headless. Browser apps inject the popup transport:

```js
import { createBrowserPasskeyLogin } from '@noiseflood/auth/browser'

const auth = createAuthClient({
  baseURL: 'https://noiseflood.farm/v1',
  passkey: createBrowserPasskeyLogin({ clientId: 'morph' }),
})
// Invoke directly from a click handler to retain the browser's popup permission.
await auth.loginWithPasskey()
```

The transport returns a single-use `{ code, code_verifier, client_id, redirect_uri }`
handoff. The client exchanges it once and accepts the existing session response.
Cancellation is `PASSKEY_CANCELLED`, without a persistent login error. Logout and
disposal cancel pending prompts; simultaneous sign-in operations are rejected.
A failed network exchange is never replayed automatically.

Electron main processes import `registerElectronPasskeyHandlers` from
`@noiseflood/auth/electron`, inject their validated sender/window boundary, and
package the narrow `@noiseflood/auth/electron-preload` entry point. Desktop login
uses a hidden, isolated transport window and presents Apple's AuthenticationServices
sheet on the main app window. Enrollment and management keep their visible modal.
The renderer adapter calls the validated app IPC bridge and
passes its handoff into this same client. Missing native support leaves password
sign-in available. See [native setup and device validation](native/docs/BUILD.md).
Web consumers do not load Electron or native code.

For optional startup sign-in, construct `createDesktopPasskeyStartup` from
`@noiseflood/auth/startup` once for the app lifetime. Supply `initialize`, `getState`,
`login` and `isSupported` callbacks. Mount it with the authentication UI and run
the returned cleanup on unmount. Call `suppress()` before an explicit login,
logout, or local session clear. It waits for anonymous session restoration and
a visible, focused app, then attempts `loginWithPasskey({
preferImmediatelyAvailableCredentials: true })` once. Restored sessions skip the
prompt. Cancellation, no local credential, or unavailable native support leaves
ordinary sign-in available without an automatic retry. Never point its login
callback at a browser popup. A desktop menu that logs out and reloads the renderer
must also call the main controller's `suppressAutomaticLogin()`.

Updated app preloads expose the fixed capability `passkeys.supportsAutomaticLogin: true`.
The adapter's `isSupported` callback must require this marker and macOS, and the
transport must reject an immediate-only request if the marker is absent. This
keeps hosted renderers compatible with older desktop shells that ignore options.

Automatic mode needs the 0.4.0 native addon. An older addon is safely skipped;
manual passkey sign-in continues to work. Apple controls its account chooser,
biometric prompt and password fallback; apps cannot force fingerprint-only UI.

Consumers include Morph, Flooder, Manager and Floodgate. Server enrollment,
verification, credential management and release requirements are documented in
`docs/security/shared-auth.md` in the Farm API repository. Native iOS/iPadOS
clients use the server contract separately.

Run `npm test` in this directory. Create an installable archive with `npm pack`.
Increment the package version for each consumer release; applications must be
rebuilt to adopt a new version. No native compilation happens at npm install time.

The repository's `update-consumers.py` previews all consumers in `consumers.json`.
Use `--apply` to pack once and update all archives and npm lockfiles, or add
`--commit` to commit those dependency changes on each app's develop branch.
It resolves dependencies in temporary directories first and never installs into
running apps, changes app release versions, tags, pushes or deploys. Existing
archives are immutable: bump the package version for any content change.
