export interface DesktopPasskeyStartupOptions {
  initialize(): Promise<unknown>;
  getState(): { readonly status: string };
  login(options: { preferImmediatelyAvailableCredentials: true }): Promise<unknown>;
  /** Return true only for a native desktop passkey transport; never a browser popup. */
  isSupported(): boolean;
  document?: Pick<Document, "hidden" | "hasFocus" | "addEventListener" | "removeEventListener">;
  window?: Pick<Window, "addEventListener" | "removeEventListener">;
}

export interface DesktopPasskeyStartup {
  /** Call when mounting the auth UI; return value removes pending startup listeners. */
  mount(): () => void;
  /** Permanently skip automatic startup after explicit login, logout or clearing a session. */
  suppress(): void;
}

export declare function createDesktopPasskeyStartup(options: DesktopPasskeyStartupOptions): DesktopPasskeyStartup;
