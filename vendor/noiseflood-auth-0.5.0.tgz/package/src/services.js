import { AuthError } from './index.js'

const CONTRACT = 'farm.service-access/1'
const READ_METHODS = new Set(['GET', 'HEAD'])
const SCOPE = /^[a-z][a-z0-9._:-]*$/
const ID = /^[a-z0-9][a-z0-9._-]{0,63}$/
const unwrap = value => value?.data ?? value
const contextKey = context => JSON.stringify([context.baseURL, context.mode, context.accountId, context.appSessionId, context.clientId, context.generation, context.status])
const failure = (message, code = 'INVALID_RESPONSE', status) => new AuthError(message, { code, status })

function httpsURL(value) {
  let url
  try { url = new URL(value) } catch { throw failure('Invalid trusted service URL') }
  if (url.protocol !== 'https:' || url.username || url.password || url.search || url.hash) throw failure('Service destinations must use HTTPS without credentials, query or fragment')
  url.pathname = `${url.pathname.replace(/\/+$/, '')}/`
  return url
}

function scopedPath(path, base) {
  if (typeof path !== 'string' || !path || path.startsWith('//') || /[\\#\u0000-\u0020]/.test(path)) throw failure('Use a relative service path', 'INVALID_PATH')
  const relative = path.replace(/^\//, '')
  const pathname = relative.split('?')[0]
  if (!pathname || pathname.includes(':')) throw failure('Use a relative service path', 'INVALID_PATH')
  for (const part of pathname.split('/')) {
    let decoded = part
    try {
      for (let i = 0; i < 5; i++) {
        const next = decodeURIComponent(decoded)
        if (next === '.' || next === '..' || /[\\/\u0000-\u0020]/.test(next)) throw new Error('unsafe path')
        if (decoded === next) break
        decoded = next
      }
      if (/%(?:2e|2f|5c|25)/i.test(decoded)) throw new Error('nested encoding')
    } catch { throw failure('Service paths cannot traverse or contain encoded separators', 'INVALID_PATH') }
  }
  const url = new URL(relative, base)
  if (url.origin !== base.origin || !url.pathname.startsWith(base.pathname)) throw failure('The path escapes the service base', 'INVALID_PATH')
  return url.href
}

function scopeSet(value) {
  if (!Array.isArray(value) || value.some(scope => typeof scope !== 'string' || !SCOPE.test(scope))) throw failure('Scopes must be explicit registered names', 'invalid_scope', 400)
  return [...new Set(value)].sort()
}

function checkSignal(signal) {
  if (signal?.aborted) throw failure('The request was cancelled', 'ABORTED')
}

function waitFor(promise, signal) {
  if (!signal) return promise
  if (signal.aborted) return Promise.reject(failure('The request was cancelled', 'ABORTED'))
  return new Promise((resolve, reject) => {
    const abort = () => reject(failure('The request was cancelled', 'ABORTED'))
    signal.addEventListener('abort', abort, { once: true })
    promise.then(resolve, reject).finally(() => signal.removeEventListener('abort', abort)).catch(() => {})
  })
}

/** Native service connections. Tokens remain private to this in-memory provider. */
export function createServiceClient({ auth, issuer, fetch: fetchOverride, timeoutMs = 30000, now = Date.now } = {}) {
  if (!auth || ['initialize', 'request', 'getSessionContext', 'subscribeSession'].some(key => typeof auth[key] !== 'function')) throw new TypeError('An auth client with session context support is required')
  const issuerURL = httpsURL(issuer)
  if (issuer !== issuerURL.href.replace(/\/$/, '')) throw new TypeError('issuer must be the exact pinned HTTPS issuer without a trailing slash')
  const fetcher = fetchOverride ?? globalThis.fetch?.bind(globalThis)
  if (typeof fetcher !== 'function' || typeof now !== 'function') throw new TypeError('fetch and now must be functions')
  if (!Number.isFinite(timeoutMs) || timeoutMs <= 0) throw new TypeError('timeoutMs must be positive')
  let disposed = false
  let observed = contextKey(auth.getSessionContext())
  let discovery = null
  let discovering = null
  const credentials = new Map()
  const acquisitions = new Map()
  const controllers = new Set()

  function invalidate() {
    discovery = null
    discovering = null
    credentials.clear()
    acquisitions.clear()
    for (const controller of controllers) controller.abort()
    controllers.clear()
  }
  const unsubscribe = auth.subscribeSession(context => {
    const next = contextKey(context)
    if (next !== observed) { observed = next; invalidate() }
  })

  function assertCurrent(context) {
    if (disposed) throw failure('The service client has been disposed', 'DISPOSED')
    if (contextKey(context) !== contextKey(auth.getSessionContext())) throw failure('The account or app session changed', 'SESSION_CHANGED')
  }

  async function ready() {
    if (disposed) throw failure('The service client has been disposed', 'DISPOSED')
    const started = auth.getSessionContext()
    if (started.mode !== 'bearer') throw failure('Service access requires an isolated native app session', 'app_session_binding_required', 409)
    await auth.initialize()
    const context = auth.getSessionContext()
    if (started.generation !== context.generation || started.baseURL !== context.baseURL || started.accountId != null && started.accountId !== context.accountId || started.appSessionId != null && started.appSessionId !== context.appSessionId) throw failure('The account changed while opening the service connection', 'SESSION_CHANGED')
    if (context.status !== 'authenticated' || !context.accountId) throw failure('Sign in to Farm to access services', 'invalid_token', 401)
    if (!context.appSessionId || !context.clientId) throw failure('Bind this app session before requesting service access', 'app_session_binding_required', 409)
    return context
  }

  async function central(path, options, context) {
    assertCurrent(context)
    const controller = new AbortController()
    controllers.add(controller)
    try {
      const result = unwrap(await auth.request(path, { ...options, signal: controller.signal }))
      assertCurrent(context)
      return result
    } finally { controllers.delete(controller) }
  }

  function validateService(service) {
    if (!service || !ID.test(service.service_id) || typeof service.audience !== 'string' || !service.audience || typeof service.enabled !== 'boolean' || !['available', 'denied', 'disabled'].includes(service.access)) throw failure('Invalid service catalog entry')
    const base = httpsURL(service.base_url)
    const scopes = scopeSet(service.scopes)
    const available = scopeSet(service.available_scopes)
    if (available.some(scope => !scopes.includes(scope))) throw failure('Service discovery returned unknown available scopes')
    if (service.capabilities_path != null) scopedPath(service.capabilities_path, base)
    return Object.freeze({ ...service, base_url: base.href, scopes: Object.freeze(scopes), available_scopes: Object.freeze(available) })
  }

  function catalog(context, force = false) {
    assertCurrent(context)
    if (discovering) return discovering
    if (!force && discovery && discovery.expiresAt > now()) return Promise.resolve(discovery.value)
    const pending = (async () => {
      const capabilities = await central('auth/capabilities', { skipAuth: true }, context)
      if (capabilities?.contract !== CONTRACT || capabilities.issuer !== issuer || capabilities.service_token_lifetime !== 300 || capabilities.services_url !== new URL('auth/services', context.baseURL).href || capabilities.service_token_url !== new URL('auth/service-token', context.baseURL).href) throw failure('The Farm service-access contract does not match this client', 'CONTRACT_UNSUPPORTED')
      const data = await central('auth/services', {}, context)
      if (data?.contract !== CONTRACT || data.issuer !== issuer || data.app_session?.id !== context.appSessionId || data.app_session?.client_id !== context.clientId || !Array.isArray(data.services)) throw failure('Service discovery did not match the bound app session', 'CONTRACT_UNSUPPORTED')
      const services = data.services.map(validateService)
      if (new Set(services.map(service => service.service_id)).size !== services.length) throw failure('Service discovery contains duplicate identifiers')
      const value = Object.freeze(services)
      assertCurrent(context)
      discovery = { value, expiresAt: now() + 60000 }
      return value
    })()
    discovering = pending
    void pending.finally(() => { if (discovering === pending) discovering = null }).catch(() => {})
    return pending
  }

  function requireService(services, serviceId, scopes) {
    const service = services.find(item => item.service_id === serviceId)
    if (!service) throw failure('The requested service is not registered', 'invalid_service', 400)
    if (!service.enabled || service.access === 'disabled') throw failure('The service is disabled', 'service_unavailable', 503)
    if (service.auth_contract !== CONTRACT) throw failure('The service needs a compatible auth contract', 'CONTRACT_UNSUPPORTED')
    if (service.access !== 'available') throw failure('This account cannot access this service', 'service_access_denied', 403)
    if (scopes.some(scope => !service.scopes.includes(scope))) throw failure('A requested scope is unknown', 'invalid_scope', 400)
    if (scopes.some(scope => !service.available_scopes.includes(scope))) throw failure('This account lacks a requested service permission', 'insufficient_scope', 403)
    return service
  }

  function credentialKey(context, service, scopes) {
    return JSON.stringify([issuer, context.accountId, context.appSessionId, context.generation, service.service_id, service.audience, service.base_url, scopes])
  }

  function acquire(context, service, scopes, rejectedToken) {
    assertCurrent(context)
    const key = credentialKey(context, service, scopes)
    const cached = credentials.get(key)
    if (cached && cached.expiresAt - now() > 30000 && cached.token !== rejectedToken) return Promise.resolve(cached)
    if (acquisitions.has(key)) return acquisitions.get(key)
    if (cached?.token === rejectedToken) credentials.delete(key)
    const pending = (async () => {
      // A connection never changes destination underneath an in-flight document.
      const current = requireService(await catalog(context, true), service.service_id, scopes)
      if (current.base_url !== service.base_url || current.audience !== service.audience) throw failure('The service destination changed; create a new connection', 'SERVICE_CHANGED')
      const started = now()
      const data = await central('auth/service-token', { method: 'POST', body: { service_id: service.service_id, scopes } }, context)
      if (data?.contract !== CONTRACT || data.service_id !== service.service_id || data.audience !== service.audience || data.token_type !== 'Bearer' || typeof data.access_token !== 'string' || !data.access_token || !Number.isInteger(data.expires_in) || data.expires_in < 1 || data.expires_in > 300 || data.scope !== scopes.join(' ')) throw failure('The issued service credential does not match the requested access')
      const credential = { token: data.access_token, expiresAt: started + data.expires_in * 1000 }
      if (credential.expiresAt <= now()) throw failure('The issued service credential expired before use', 'invalid_token', 401)
      assertCurrent(context)
      credentials.set(key, credential)
      return credential
    })()
    acquisitions.set(key, pending)
    void pending.finally(() => { if (acquisitions.get(key) === pending) acquisitions.delete(key) }).catch(() => {})
    return pending
  }

  async function discover({ signal } = {}) {
    checkSignal(signal)
    const context = await ready()
    return waitFor(catalog(context), signal)
  }

  async function connect(serviceId, { scopes: requested = [], signal } = {}) {
    if (typeof serviceId !== 'string' || !ID.test(serviceId)) throw failure('A registered service identifier is required', 'invalid_service', 400)
    const scopes = Object.freeze(scopeSet(requested))
    checkSignal(signal)
    const context = await ready()
    const service = requireService(await waitFor(catalog(context), signal), serviceId, scopes)
    assertCurrent(context)
    const base = httpsURL(service.base_url)
    let closed = false
    const connectionControllers = new Set()
    function valid() {
      if (closed) throw failure('The service connection has been disposed', 'DISPOSED')
      assertCurrent(context)
    }

    async function send(path, options, credential) {
      valid()
      const url = scopedPath(path, base)
      const method = (options.method ?? 'GET').toUpperCase()
      const requestTimeout = options.timeoutMs ?? timeoutMs
      if (!Number.isFinite(requestTimeout) || requestTimeout <= 0) throw new TypeError('timeoutMs must be positive')
      if (!['json', 'text', 'blob', 'arrayBuffer'].includes(options.responseType ?? 'json')) throw new TypeError('Use a buffered service response type')
      const headers = new Headers(options.headers)
      for (const name of ['authorization', 'cookie', 'x-client-type', 'x-refresh-token', 'x-csrf-token', 'x-api-key', 'proxy-authorization']) headers.delete(name)
      headers.set('Authorization', `Bearer ${credential.token}`)
      let body = options.body
      if ((body != null && Object.getPrototypeOf(body) === Object.prototype) || Array.isArray(body)) {
        body = JSON.stringify(body)
        if (!headers.has('Content-Type')) headers.set('Content-Type', 'application/json')
      }
      const controller = new AbortController()
      controllers.add(controller)
      connectionControllers.add(controller)
      const abort = () => controller.abort(options.signal?.reason)
      if (options.signal?.aborted) abort()
      else options.signal?.addEventListener('abort', abort, { once: true })
      let timedOut = false
      const timeout = setTimeout(() => { timedOut = true; controller.abort() }, requestTimeout)
      try {
        checkSignal(options.signal)
        const response = await fetcher(url, { method, headers, body, signal: controller.signal, credentials: 'omit', redirect: 'error', cache: 'no-store' })
        valid()
        if (timedOut) throw failure('The service request timed out', 'TIMEOUT')
        if (response.redirected || response.url && response.url !== url) throw failure('Service redirects are not allowed', 'INVALID_REDIRECT')
        if (!response.ok) {
          let payload
          try { payload = await response.json() } catch { payload = null }
          valid()
          const details = payload?.error && typeof payload.error === 'object' ? payload.error : payload
          const retry = response.headers.get('Retry-After')
          const retryAfter = retry == null ? undefined : /^\d+$/.test(retry) ? Number(retry) : Math.max(0, Math.ceil((Date.parse(retry) - now()) / 1000))
          throw new AuthError(typeof details?.message === 'string' ? details.message : `Service request failed (${response.status})`, {
            status: response.status,
            code: typeof details?.code === 'string' ? details.code : typeof payload?.error === 'string' ? payload.error : 'HTTP_ERROR',
            requestId: typeof payload?.request_id === 'string' ? payload.request_id : undefined,
            retryAfter: Number.isFinite(retryAfter) ? retryAfter : undefined,
          })
        }
        if (response.status === 204 || method === 'HEAD') return null
        let result
        try { result = await response[options.responseType ?? 'json']() } catch (cause) {
          if ((options.responseType ?? 'json') === 'json' && cause instanceof SyntaxError) throw new AuthError('The service returned invalid JSON', { code: 'INVALID_RESPONSE', status: response.status, cause })
          throw cause
        }
        valid()
        if (timedOut) throw failure('The service request timed out', 'TIMEOUT')
        checkSignal(options.signal)
        return result
      } catch (error) {
        valid()
        if (error instanceof AuthError) throw error
        if (timedOut) throw failure('The service request timed out', 'TIMEOUT')
        checkSignal(options.signal)
        throw new AuthError('Unable to complete the service request', { code: 'NETWORK_ERROR', cause: error })
      } finally {
        clearTimeout(timeout)
        controllers.delete(controller)
        connectionControllers.delete(controller)
        options.signal?.removeEventListener('abort', abort)
      }
    }

    return Object.freeze({
      serviceId, baseURL: base.href, audience: service.audience, issuer, accountId: context.accountId,
      appSessionId: context.appSessionId, generation: context.generation, scopes,
      assertCurrent: valid,
      async request(path, options = {}) {
        valid()
        scopedPath(path, base)
        checkSignal(options.signal)
        let credential = await waitFor(acquire(context, service, scopes), options.signal)
        valid()
        try { return await send(path, options, credential) } catch (error) {
          if (error.status !== 401 || error.code !== 'invalid_token') throw error
          const key = credentialKey(context, service, scopes)
          if (credentials.get(key)?.token === credential.token) credentials.delete(key)
          if (!READ_METHODS.has((options.method ?? 'GET').toUpperCase())) throw error
          credential = await waitFor(acquire(context, service, scopes, credential.token), options.signal)
          valid()
          return send(path, options, credential)
        }
      },
      dispose() { closed = true; for (const controller of connectionControllers) controller.abort(); connectionControllers.clear() },
    })
  }

  return Object.freeze({
    discover, connect,
    dispose() { if (disposed) return; disposed = true; unsubscribe(); invalidate() },
  })
}
