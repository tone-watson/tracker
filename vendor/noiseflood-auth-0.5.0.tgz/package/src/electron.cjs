"use strict";

const { randomBytes, createHash } = require("node:crypto");

const ORIGIN = "https://noiseflood.farm";
const PORTAL = `${ORIGIN}/v1/auth/passkeys/ui`;
const CLIENTS = new Set(["morph", "flooder", "manager", "floodgate"]);
const CHANNELS = [
  "passkeys:login",
  "passkeys:cancel",
  "passkeys:manage",
  "farm-passkeys:get",
  "farm-passkeys:create",
  "farm-passkeys:complete",
  "farm-passkeys:ready",
  "farm-passkeys:fail",
];
const failure = (code, error) => ({ ok: false, code, error });
const cancelled = () =>
  failure("PASSKEY_CANCELLED", "Passkey sign-in was cancelled.");
const unsupported = () =>
  failure(
    "PASSKEY_UNSUPPORTED",
    "Passkeys require the signed macOS app and its native passkey component.",
  );
const validBytes = (value, min = 1, max = 65536) =>
  typeof value === "string" &&
  value.length >= min &&
  value.length <= max &&
  /^[A-Za-z0-9_-]+$/.test(value) &&
  Buffer.from(value, "base64url").toString("base64url") === value;

function validOptions(kind, value) {
  if (
    !value ||
    typeof value !== "object" ||
    !validBytes(value.challenge, 32, 512)
  )
    return false;
  if (kind === "get") {
    return (
      value.rpId === "noiseflood.farm" &&
      value.userVerification === "required" &&
      (!value.allowCredentials ||
        (Array.isArray(value.allowCredentials) &&
          value.allowCredentials.length <= 32 &&
          value.allowCredentials.every(
            (item) =>
              item?.type === "public-key" && validBytes(item.id, 1, 2048),
          )))
    );
  }
  return (
    value.rp?.id === "noiseflood.farm" &&
    value.authenticatorSelection?.userVerification === "required" &&
    value.authenticatorSelection?.residentKey === "required" &&
    value.attestation === "none" &&
    validBytes(value.user?.id, 1, 86) &&
    Buffer.byteLength(value.user.id, "base64url") <= 64 &&
    typeof value.user.name === "string" &&
    value.user.name.length > 0 &&
    value.user.name.length <= 320 &&
    typeof value.user.displayName === "string" &&
    value.user.displayName.length <= 320 &&
    Array.isArray(value.pubKeyCredParams) &&
    value.pubKeyCredParams.some(
      (item) => item?.type === "public-key" && item.alg === -7,
    ) &&
    (!value.excludeCredentials ||
      (Array.isArray(value.excludeCredentials) &&
        value.excludeCredentials.length <= 32 &&
        value.excludeCredentials.every(
          (item) => item?.type === "public-key" && validBytes(item.id, 1, 2048),
        )))
  );
}

function validCredential(kind, value) {
  if (
    !value ||
    value.type !== "public-key" ||
    !validBytes(value.id, 1, 2048) ||
    value.rawId !== value.id ||
    !validBytes(value.response?.clientDataJSON)
  )
    return false;
  return kind === "get"
    ? validBytes(value.response.authenticatorData) &&
        validBytes(value.response.signature) &&
        validBytes(value.response.userHandle, 1, 86)
    : validBytes(value.response.attestationObject);
}

function awaitNative(operation, signal) {
  return new Promise((resolve, reject) => {
    const stop = () =>
      reject(
        Object.assign(new Error("Cancelled"), { code: "PASSKEY_CANCELLED" }),
      );
    if (signal.aborted) {
      stop();
      return;
    }
    signal.addEventListener("abort", stop, { once: true });
    Promise.resolve()
      .then(() => {
        if (signal.aborted)
          throw Object.assign(new Error("Cancelled"), {
            code: "PASSKEY_CANCELLED",
          });
        return operation();
      })
      .then(resolve, reject)
      .finally(() => signal.removeEventListener("abort", stop));
  });
}

/** Main-process-only controller. Electron is injected to keep tests and imports headless. */
function createElectronPasskeys({
  clientId,
  BrowserWindow,
  getWindow,
  nativePath,
  preloadPath,
  loadNative = require,
  platform = process.platform,
  timeoutMs = 120000,
}) {
  if (
    !CLIENTS.has(clientId) ||
    typeof getWindow !== "function" ||
    typeof BrowserWindow !== "function" ||
    !nativePath ||
    !preloadPath
  )
    throw new TypeError("Invalid desktop passkey configuration");
  if (!Number.isFinite(timeoutMs) || timeoutMs <= 0 || timeoutMs > 300000)
    throw new TypeError("Invalid passkey timeout");
  let active = null;
  let disposed = false;
  let native;
  let automaticAttempted = false;

  function finish(flow, result) {
    if (active !== flow) return;
    active = null;
    clearTimeout(flow.timer);
    flow.abort.abort();
    flow.owner.removeListener("closed", flow.ownerClosed);
    flow.owner.webContents.removeListener(
      "did-start-navigation",
      flow.ownerNavigation,
    );
    flow.owner.webContents.removeListener("destroyed", flow.ownerClosed);
    try {
      native?.cancel();
    } catch {
      /* Completion must still close the dialog. */
    }
    if (!flow.popup.isDestroyed()) flow.popup.destroy();
    flow.resolve(result);
  }

  function trustedPopup(event) {
    const flow = active;
    try {
      return !!(
        flow &&
        !flow.owner.isDestroyed() &&
        getWindow() === flow.owner &&
        flow.owner.webContents.mainFrame === flow.ownerFrame &&
        !flow.popup.isDestroyed() &&
        event.sender === flow.popup.webContents &&
        event.senderFrame === flow.popup.webContents.mainFrame &&
        event.senderFrame.url === flow.url &&
        flow.popup.webContents.getURL() === flow.url
      );
    } catch {
      return false;
    }
  }

  async function open(mode, options = {}) {
    if (disposed)
      return failure("SESSION_CHANGED", "The application is closing.");
    if (active)
      return failure("SESSION_CHANGED", "A passkey window is already open.");
    if (
      !options ||
      typeof options !== "object" ||
      Array.isArray(options) ||
      (options.preferImmediatelyAvailableCredentials !== undefined &&
        typeof options.preferImmediatelyAvailableCredentials !== "boolean")
    )
      return failure("INVALID_RESPONSE", "Invalid passkey request.");
    const immediate =
      mode === "login" &&
      options.preferImmediatelyAvailableCredentials === true;
    if (immediate && automaticAttempted) return cancelled();
    const owner = getWindow();
    if (!owner || owner.isDestroyed())
      return failure("SESSION_CHANGED", "The application window closed.");
    if (immediate) automaticAttempted = true;
    if (platform !== "darwin") return unsupported();
    try {
      native ||= loadNative(nativePath);
      if (
        !native.isAvailable() ||
        typeof native.requestAssertion !== "function" ||
        typeof native.requestRegistration !== "function" ||
        typeof native.cancel !== "function"
      )
        return unsupported();
      // Older native components ignore unknown options. Never let an automatic
      // attempt silently turn into a QR-code prompt on those builds.
      if (
        immediate &&
        native.supportsImmediatelyAvailableCredentials?.() !== true
      )
        return unsupported();
    } catch {
      return unsupported();
    }
    const verifier = randomBytes(32).toString("base64url");
    const state = randomBytes(32).toString("base64url");
    const redirect = `https://${clientId}.noiseflood.farm`;
    const url = new URL(PORTAL);
    if (mode === "login") {
      url.search = new URLSearchParams({
        client_id: clientId,
        redirect_uri: redirect,
        state,
        code_challenge: createHash("sha256")
          .update(verifier)
          .digest("base64url"),
      }).toString();
    }
    let popup;
    try {
      popup = new BrowserWindow({
        parent: owner,
        modal: mode === "manage",
        width: 480,
        height: 660,
        minWidth: 360,
        minHeight: 440,
        show: false,
        autoHideMenuBar: true,
        title: "Noiseflood passkeys",
        backgroundColor: "#161719",
        webPreferences: {
          preload: preloadPath,
          partition: `farm-passkeys-${randomBytes(24).toString("hex")}`,
          contextIsolation: true,
          sandbox: true,
          nodeIntegration: false,
          webviewTag: false,
          webSecurity: true,
          allowRunningInsecureContent: false,
          backgroundThrottling: mode !== "login",
        },
      });
    } catch {
      return failure(
        "PASSKEY_UNAVAILABLE",
        "The passkey window could not be opened.",
      );
    }
    let resolve;
    const result = new Promise((done) => {
      resolve = done;
    });
    const flow = {
      mode,
      popup,
      owner,
      ownerFrame: owner.webContents.mainFrame,
      url: url.href,
      verifier,
      state,
      redirect,
      resolve,
      nativePending: false,
      immediate,
      ready: false,
      abort: new AbortController(),
    };
    active = flow;
    flow.ownerClosed = () => finish(flow, cancelled());
    flow.ownerNavigation = (_event, _url, inPlace, mainFrame) => {
      if (mainFrame && !inPlace) finish(flow, cancelled());
    };
    owner.once("closed", flow.ownerClosed);
    owner.webContents.once("destroyed", flow.ownerClosed);
    owner.webContents.on("did-start-navigation", flow.ownerNavigation);
    flow.timer = setTimeout(
      () =>
        finish(
          flow,
          failure("TIMEOUT", "Passkey sign-in timed out. Try again."),
        ),
      mode === "login" ? timeoutMs : 15 * 60 * 1000,
    );
    popup.on("closed", () => finish(flow, cancelled()));
    popup.webContents.setWindowOpenHandler(() => ({ action: "deny" }));
    popup.webContents.on("will-navigate", (event, target) => {
      if (target !== flow.url) {
        event.preventDefault();
        finish(
          flow,
          failure(
            "PASSKEY_UNAVAILABLE",
            "Unexpected passkey navigation was blocked.",
          ),
        );
      }
    });
    popup.webContents.on("will-redirect", (event) => {
      event.preventDefault();
      finish(
        flow,
        failure(
          "PASSKEY_UNAVAILABLE",
          "Unexpected passkey redirect was blocked.",
        ),
      );
    });
    popup.webContents.on("will-attach-webview", (event) =>
      event.preventDefault(),
    );
    popup.webContents.on("render-process-gone", () =>
      finish(
        flow,
        failure(
          "PASSKEY_UNAVAILABLE",
          "The passkey window closed unexpectedly.",
        ),
      ),
    );
    popup.webContents.session.setPermissionRequestHandler(
      (_contents, _permission, callback) => callback(false),
    );
    popup.webContents.session.setPermissionCheckHandler(() => false);
    Promise.resolve()
      .then(() => popup.loadURL(flow.url))
      .then(
        () => {
          if (active === flow && mode === "manage") {
            popup.show();
            popup.focus();
            resolve({ ok: true });
          }
        },
        () =>
          finish(
            flow,
            failure(
              "NETWORK_ERROR",
              "The passkey service could not be reached.",
            ),
          ),
      );
    // Management owns a long-lived modal, but the renderer need not await its close.
    return result;
  }

  async function credential(kind, event, options) {
    if (!trustedPopup(event))
      return failure("UNTRUSTED_SENDER", "Untrusted passkey request.");
    if (!validOptions(kind, options))
      return failure("INVALID_RESPONSE", "Invalid passkey options.");
    const flow = active;
    if (flow.mode === "login" && kind !== "get")
      return failure(
        "INVALID_RESPONSE",
        "Enrollment requires the passkey settings window.",
      );
    if (flow.nativePending)
      return failure("SESSION_CHANGED", "A passkey prompt is already open.");
    flow.nativePending = true;
    try {
      const method =
        kind === "get" ? "requestAssertion" : "requestRegistration";
      const descriptors = (items) =>
        items?.map(({ id }) => ({ id, type: "public-key" }));
      const request =
        kind === "get"
          ? {
              challenge: options.challenge,
              rpId: "noiseflood.farm",
              allowCredentials: descriptors(options.allowCredentials),
              preferImmediatelyAvailableCredentials:
                flow.mode === "login" && flow.immediate,
            }
          : {
              challenge: options.challenge,
              rp: { id: "noiseflood.farm" },
              user: {
                id: options.user.id,
                name: options.user.name,
                displayName: options.user.displayName,
              },
              excludeCredentials: descriptors(options.excludeCredentials),
            };
      const data = await awaitNative(() => {
        // Startup may have been foregrounded before a slow portal request.
        // Never interrupt another app when those options eventually arrive.
        if (
          flow.immediate &&
          (!flow.owner.isVisible() || !flow.owner.isFocused())
        )
          throw Object.assign(new Error("Cancelled"), {
            code: "PASSKEY_CANCELLED",
          });
        return native[method]({
          ...request,
          windowHandle: (flow.mode === "login"
            ? flow.owner
            : flow.popup
          ).getNativeWindowHandle(),
        });
      }, flow.abort.signal);
      if (active !== flow || !trustedPopup(event)) return cancelled();
      if (!validCredential(kind, data))
        return failure(
          "INVALID_RESPONSE",
          "The native passkey response was invalid.",
        );
      return { ok: true, data };
    } catch (error) {
      if (active !== flow || error?.code === "PASSKEY_CANCELLED")
        return cancelled();
      if (error?.code === "PASSKEY_UNSUPPORTED") return unsupported();
      return failure(
        "PASSKEY_FAILED",
        "The passkey request could not be completed. Check Apple Passwords and the app's domain association.",
      );
    } finally {
      flow.nativePending = false;
    }
  }

  return {
    login: (options) => open("login", options),
    suppressAutomaticLogin() {
      automaticAttempted = true;
    },
    manage: () => open("manage"),
    cancel() {
      if (active) finish(active, cancelled());
      return { ok: true };
    },
    credential,
    ready(event) {
      if (!trustedPopup(event))
        return failure("UNTRUSTED_SENDER", "Untrusted passkey request.");
      const flow = active;
      if (flow.ready)
        return failure(
          "SESSION_CHANGED",
          "The passkey window is already ready.",
        );
      flow.ready = true;
      return { ok: true, data: { mode: flow.mode } };
    },
    fail(event, data) {
      if (!trustedPopup(event))
        return failure("UNTRUSTED_SENDER", "Untrusted passkey failure.");
      const flow = active;
      const failures = {
        PASSKEY_CANCELLED: cancelled(),
        PASSKEY_UNSUPPORTED: unsupported(),
        NETWORK_ERROR: failure(
          "NETWORK_ERROR",
          "The passkey service could not be reached.",
        ),
        RATE_LIMITED: failure(
          "RATE_LIMITED",
          "Too many passkey attempts. Please wait before trying again.",
        ),
        TIMEOUT: failure("TIMEOUT", "Passkey sign-in timed out. Try again."),
        INVALID_RESPONSE: failure(
          "INVALID_RESPONSE",
          "The passkey service returned an invalid response.",
        ),
        PASSKEY_FAILED: failure(
          "PASSKEY_FAILED",
          "Passkey sign-in could not be completed. Try again or use your password.",
        ),
      };
      if (
        flow.mode !== "login" ||
        !flow.ready ||
        flow.nativePending ||
        data?.state !== flow.state ||
        data?.client_id !== clientId ||
        !Object.hasOwn(failures, data?.code)
      )
        return failure("INVALID_RESPONSE", "Invalid passkey failure.");
      finish(flow, failures[data.code]);
      return { ok: true };
    },
    complete(event, data) {
      if (!trustedPopup(event))
        return failure("UNTRUSTED_SENDER", "Untrusted passkey completion.");
      const flow = active;
      if (
        flow.mode !== "login" ||
        flow.nativePending ||
        data?.state !== flow.state ||
        data?.client_id !== clientId ||
        !validBytes(data?.code, 43, 43)
      )
        return failure("INVALID_RESPONSE", "Invalid passkey completion.");
      finish(flow, {
        ok: true,
        data: {
          code: data.code,
          code_verifier: flow.verifier,
          client_id: clientId,
          redirect_uri: flow.redirect,
        },
      });
      return { ok: true };
    },
    dispose() {
      disposed = true;
      if (active) finish(active, cancelled());
    },
  };
}

function registerElectronPasskeyHandlers({
  ipcMain,
  app,
  isTrustedSender,
  ...options
}) {
  const controller = createElectronPasskeys(options);
  for (const method of ["login", "cancel", "manage"]) {
    ipcMain.handle(`passkeys:${method}`, async (event, options) => {
      if (!isTrustedSender(event))
        return failure("UNTRUSTED_SENDER", "Untrusted passkey request.");
      const result = await controller[method](
        method === "login" ? options : undefined,
      );
      return isTrustedSender(event) ? result : cancelled();
    });
  }
  for (const kind of ["get", "create"])
    ipcMain.handle(`farm-passkeys:${kind}`, (event, options) =>
      controller.credential(kind, event, options),
    );
  ipcMain.handle("farm-passkeys:complete", (event, data) =>
    controller.complete(event, data),
  );
  ipcMain.handle("farm-passkeys:ready", (event) => controller.ready(event));
  ipcMain.handle("farm-passkeys:fail", (event, data) =>
    controller.fail(event, data),
  );
  const close = () => controller.dispose();
  app.once("before-quit", close);
  return {
    ...controller,
    dispose() {
      controller.dispose();
      app.removeListener("before-quit", close);
      for (const name of CHANNELS) ipcMain.removeHandler(name);
    },
  };
}

module.exports = { createElectronPasskeys, registerElectronPasskeyHandlers };
