export interface TokenPair {
  access_token: string
  refresh_token: string
  /** Persist atomically with the pair for bound sessions. Never silently discard. */
  app_session?: { id: string; client_id: string; expires_at?: string }
  /** Protected write-ahead marker: rotation may have consumed this refresh token. */
  refresh_pending?: boolean
}

export interface TokenStore {
  /** Required for bound/new native clients: save atomically retains all metadata. */
  supportsSessionJournal?: true
  load(): Promise<TokenPair | null>
  /** Atomically replace the entire protected record, including optional metadata. */
  save(tokens: TokenPair): Promise<void>
  clear(): Promise<void>
}

export interface AuthErrorOptions {
  code?: string
  status?: number
  /** Seconds until the server permits retry, when supplied by Retry-After. */
  retryAfter?: number
  requestId?: string
  cause?: unknown
}

export class AuthError extends Error {
  constructor(message: string, options?: AuthErrorOptions)
  readonly name: "AuthError"
  readonly code: string
  readonly status?: number
  readonly retryAfter?: number
  readonly requestId?: string
}

/** Session metadata only. Authentication credentials are omitted recursively. */
export interface AuthUser {
  readonly user_id?: string | number
  readonly id?: string | number
  readonly email?: string
  readonly role?: string
  readonly global_role?: string
  readonly [key: string]: unknown
}

export interface AuthState {
  readonly status: "unknown" | "authenticated" | "anonymous"
  readonly user: AuthUser | null
  readonly error: AuthError | Error | null
  readonly expiresAt: string | null
}

export interface PasskeyHandoff {
  code: string
  code_verifier: string
  client_id: string
  redirect_uri: string
}

export interface PasskeyLoginOptions {
  /** Desktop startup only: offer a local credential or quietly return to sign-in. */
  preferImmediatelyAvailableCredentials?: boolean
}
export type PasskeyLogin = (options: PasskeyLoginOptions & { signal: AbortSignal }) => Promise<PasskeyHandoff>

export interface AuthClientOptions {
  /** HTTPS API base including version, for example https://noiseflood.farm/v1. */
  baseURL: string
  mode?: "cookie" | "bearer"
  fetch?: typeof globalThis.fetch
  /** Required for bearer mode; persistence must use OS-protected storage. */
  tokenStore?: TokenStore
  /** Trusted app-owned browser/native ceremony transport. No tokens in its return URL. */
  passkey?: PasskeyLogin
  timeoutMs?: number
  /** Disable only for servers with an access-only session protocol. Default true. */
  refresh?: boolean
  /** Disable only when the server enforces another CSRF defense. Default true. */
  csrf?: boolean
  /** Registered native client; password login checks a preapproved server grant. */
  clientId?: string
}

export interface AuthSessionContext {
  readonly baseURL: string
  readonly mode: "cookie" | "bearer"
  readonly generation: number
  readonly accountId: string | null
  readonly appSessionId: string | null
  readonly clientId: string | null
  readonly status: AuthState["status"]
}

export interface AuthRequestOptions {
  method?: string
  /** Plain objects are encoded as JSON; native fetch bodies pass through. */
  body?: BodyInit | Record<string, unknown> | readonly unknown[] | null
  headers?: HeadersInit
  signal?: AbortSignal
  /** Override the client's request timeout, in positive milliseconds. */
  timeoutMs?: number
  /** Public endpoints bypass restoration, bearer authentication and 401 refresh. */
  skipAuth?: boolean
  responseType?: "json" | "response"
}

export interface AuthClient {
  initialize(): Promise<AuthUser | null>
  login(email: string, password: string): Promise<AuthUser>
  loginWithPasskey(options?: PasskeyLoginOptions): Promise<AuthUser>
  /** Native-only, single-use S256 transition using an existing Farm session. */
  bindAppSession(options: { clientId?: string; redirectUri: string }): Promise<AuthUser>
  /** Clear local credentials only after the server acknowledges revocation. */
  logout(): Promise<void>
  refresh(): Promise<Readonly<Record<string, unknown>>>
  getCurrentUser(): Promise<AuthUser | null>
  request(path: string, options: AuthRequestOptions & { responseType: "response" }): Promise<Response>
  request<T = unknown>(path: string, options?: AuthRequestOptions): Promise<T>
  getState(): AuthState
  getSessionContext(): AuthSessionContext
  /** Fires immediately when a session generation changes, including during logout. */
  subscribeSession(listener: (context: AuthSessionContext) => void): () => void
  subscribe(listener: (state: AuthState) => void): () => void
  /** Explicit local cleanup; unlike logout(), this does not revoke server sessions. */
  clearSession(): Promise<void>
  dispose(): void
  getCsrfToken(): string | null
  refreshCsrf(): Promise<string | null>
}

export function createAuthClient(options: AuthClientOptions): AuthClient
