import type { PasskeyLogin } from './index.js'

export function createBrowserPasskeyLogin(options: {
  clientId: 'morph' | 'flooder' | 'manager' | 'floodgate' | 'manager-web' | 'floodgate-web'
  identityOrigin?: string
  window?: Window
  crypto?: Crypto
  timeoutMs?: number
}): PasskeyLogin
