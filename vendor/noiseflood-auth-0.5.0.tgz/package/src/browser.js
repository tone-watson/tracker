import { AuthError } from './index.js'

const CLIENTS = new Set(['morph', 'flooder', 'manager', 'floodgate', 'manager-web', 'floodgate-web'])
const encoded = bytes => btoa(String.fromCharCode(...bytes)).replaceAll('+', '-').replaceAll('/', '_').replace(/=+$/, '')

/** HTTPS popup handoff. WebAuthn itself stays on the one trusted identity origin. */
export function createBrowserPasskeyLogin({ clientId, identityOrigin = 'https://noiseflood.farm', window: windowOverride, crypto: cryptoOverride, timeoutMs = 120000 } = {}) {
  if (!CLIENTS.has(clientId)) throw new TypeError('Unknown Farm client')
  const identity = new URL(identityOrigin)
  if (identity.protocol !== 'https:' || identity.origin !== identityOrigin || identity.username || identity.password) throw new TypeError('Use an exact HTTPS identity origin')
  if (!Number.isFinite(timeoutMs) || timeoutMs <= 0) throw new TypeError('timeoutMs must be positive')
  return ({ signal, preferImmediatelyAvailableCredentials = false } = {}) => {
    if (preferImmediatelyAvailableCredentials) return Promise.reject(new AuthError('Automatic passkey sign-in requires the native desktop app', { code: 'PASSKEY_UNSUPPORTED' }))
    const win = windowOverride || globalThis.window
    const crypto = cryptoOverride || globalThis.crypto
    if (!win || !crypto?.subtle || win.location.protocol !== 'https:') {
      return Promise.reject(new AuthError('Passkey sign-in requires a secure browser window', { code: 'PASSKEY_UNSUPPORTED' }))
    }
    if (signal?.aborted) return Promise.reject(new AuthError('Passkey sign-in was cancelled', { code: 'PASSKEY_CANCELLED' }))
    const popup = win.open('about:blank', '_blank', 'popup,width=500,height=700')
    if (!popup) return Promise.reject(new AuthError('Allow this site to open the passkey sign-in window', { code: 'POPUP_BLOCKED' }))
    return new Promise((resolve, reject) => {
      let finished = false
      let state, verifier
      const redirect = win.location.origin
      const clean = () => {
        win.removeEventListener('message', message)
        signal?.removeEventListener('abort', cancel)
        win.clearTimeout(deadline)
        win.clearInterval(closed)
        try { popup.close() } catch { /* The provider may already have closed. */ }
      }
      const finish = (error, result) => {
        if (finished) return
        finished = true
        clean()
        if (error) reject(error)
        else resolve(result)
      }
      const cancel = () => finish(new AuthError('Passkey sign-in was cancelled', { code: 'PASSKEY_CANCELLED' }))
      const message = event => {
        if (event.source !== popup || event.origin !== identityOrigin || !state || event.data?.type !== 'noiseflood.passkey' || event.data.state !== state || event.data.client_id !== clientId) return
        const code = event.data.code
        if (typeof code !== 'string' || !/^[A-Za-z0-9_-]{32,256}$/.test(code)) return
        finish(null, { code, code_verifier: verifier, client_id: clientId, redirect_uri: redirect })
      }
      const deadline = win.setTimeout(() => finish(new AuthError('Passkey sign-in timed out. Please try again.', { code: 'TIMEOUT' })), timeoutMs)
      const closed = win.setInterval(() => { if (popup.closed) cancel() }, 300)
      win.addEventListener('message', message)
      signal?.addEventListener('abort', cancel, { once: true })
      void (async () => {
        state = encoded(crypto.getRandomValues(new Uint8Array(32)))
        verifier = encoded(crypto.getRandomValues(new Uint8Array(32)))
        const challenge = encoded(new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(verifier))))
        if (finished) return
        const url = new URL('/v1/auth/passkeys/ui', identityOrigin)
        url.search = new URLSearchParams({ client_id: clientId, redirect_uri: redirect, state, code_challenge: challenge }).toString()
        popup.location.replace(url.href)
      })().catch(error => finish(new AuthError('Unable to open passkey sign-in', { code: 'PASSKEY_FAILED', cause: error })))
    })
  }
}
