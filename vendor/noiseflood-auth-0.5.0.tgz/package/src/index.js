const BOOTSTRAP = new Set(["auth/login", "auth/passkeys/exchange", "auth/app-session/exchange", "auth/refresh", "auth/logout", "auth/refresh/csrf"])
const CSRF_ERRORS = new Set(["CSRF_TOKEN_MISSING", "CSRF_COOKIE_MISSING", "CSRF_TOKEN_INVALID", "CSRF_TOKEN_EXPIRED", "CSRF_INVALID"])
const SECRET_FIELDS = new Set(["token", "access_token", "refresh_token", "session_token", "csrf_token", "password", "password_hash", "code_verifier", "code_challenge"])
const READ_METHODS = new Set(["GET", "HEAD", "OPTIONS"])

export class AuthError extends Error {
  constructor(message, { code = "REQUEST_FAILED", status, retryAfter, requestId, cause } = {}) {
    super(message, cause === undefined ? undefined : { cause })
    this.name = "AuthError"
    this.code = code
    if (status !== undefined) this.status = status
    if (retryAfter !== undefined) this.retryAfter = retryAfter
    if (requestId !== undefined) this.requestId = requestId
  }
}

function sanitized(value) {
  if (Array.isArray(value)) return Object.freeze(value.map(sanitized))
  if (!value || typeof value !== "object") return value
  return Object.freeze(Object.fromEntries(Object.entries(value)
    .filter(([key]) => !SECRET_FIELDS.has(key.toLowerCase()))
    .map(([key, item]) => [key, sanitized(item)])))
}

function safePath(path) {
  if (typeof path !== "string" || !path || path.startsWith("//") || /[\\#\u0000-\u0020]/.test(path)) {
    throw new AuthError("Use a path relative to the configured API", { code: "INVALID_PATH" })
  }
  const pathname = path.split("?")[0].replace(/^\//, "")
  if (!pathname || pathname.includes(":")) throw new AuthError("Invalid API path", { code: "INVALID_PATH" })
  for (const segment of pathname.split("/")) {
    let decoded = segment
    try {
      for (let index = 0; index < 5; index++) {
        const next = decodeURIComponent(decoded)
        if (next === "." || next === ".." || /[\\/\u0000-\u0020]/.test(next)) throw new Error("unsafe segment")
        if (next === decoded) break
        decoded = next
      }
      if (/%(?:2e|2f|5c|25)/i.test(decoded)) throw new Error("nested encoding")
    } catch {
      throw new AuthError("API paths cannot contain traversal or encoded separators", { code: "INVALID_PATH" })
    }
  }
  return path.replace(/^\//, "")
}

function tokenPair(value, stored = false) {
  if (!value || typeof value !== "object") return null
  const access = value.access_token || value.token
  const refresh = value.refresh_token
  if (typeof access !== "string" || !access || typeof refresh !== "string" || !refresh) {
    throw new AuthError("The secure token store requires an access and refresh token", { code: "INVALID_TOKENS" })
  }
  const pair = { access_token: access, refresh_token: refresh }
  if (value.app_session !== undefined) {
    const session = value.app_session
    if (!session || typeof session.id !== "string" || !session.id || typeof session.client_id !== "string" || !session.client_id) throw new AuthError("Invalid protected app-session metadata", { code: "INVALID_TOKENS" })
    pair.app_session = { id: session.id, client_id: session.client_id }
    if (typeof session.expires_at === "string") pair.app_session.expires_at = session.expires_at
  }
  if (stored && value.refresh_pending !== undefined) {
    if (typeof value.refresh_pending !== "boolean") throw new AuthError("Invalid protected refresh journal", { code: "INVALID_TOKENS" })
    if (value.refresh_pending) pair.refresh_pending = true
  }
  return pair
}

function unwrap(value) {
  return value?.data ?? value?.user ?? value
}

/** Create an inert client. Call initialize() to restore a server-verified session. */
export function createAuthClient({ baseURL, mode = "cookie", fetch: fetchOverride, tokenStore, timeoutMs = 30000, refresh: refreshEnabled = true, csrf: csrfEnabled = true, passkey, clientId } = {}) {
  if (mode !== "cookie" && mode !== "bearer") throw new TypeError("mode must be cookie or bearer")
  if (typeof refreshEnabled !== "boolean" || typeof csrfEnabled !== "boolean") throw new TypeError("refresh and csrf must be booleans")
  if (mode === "bearer" && (!tokenStore || ["load", "save", "clear"].some((key) => typeof tokenStore[key] !== "function"))) {
    throw new TypeError("Bearer authentication requires an injected secure token store")
  }
  if (passkey !== undefined && typeof passkey !== "function") throw new TypeError("passkey must be a function")
  if (clientId !== undefined && (mode !== "bearer" || typeof clientId !== "string" || !/^[a-z0-9][a-z0-9._-]{0,63}$/.test(clientId))) throw new TypeError("clientId requires a registered native bearer client identifier")
  if (clientId !== undefined && tokenStore?.supportsSessionJournal !== true) throw new TypeError("Registered native clients require a protected store with supportsSessionJournal: true")
  if (typeof baseURL !== "string" || !baseURL) throw new TypeError("baseURL is required")
  let base
  try {
    base = new URL(baseURL, globalThis.location?.href)
  } catch {
    throw new TypeError("baseURL must be an absolute URL outside a browser")
  }
  const local = base.hostname === "localhost" || base.hostname.endsWith(".localhost") || base.hostname === "127.0.0.1" || base.hostname === "[::1]"
  if ((base.protocol !== "https:" && !(base.protocol === "http:" && local)) || base.username || base.password || base.search || base.hash) {
    throw new TypeError("baseURL requires HTTPS (HTTP is allowed only on localhost) and cannot contain credentials, query, or fragment")
  }
  base.pathname = `${base.pathname.replace(/\/+$/, "")}/`
  const fetcher = fetchOverride || globalThis.fetch?.bind(globalThis)
  if (typeof fetcher !== "function") throw new TypeError("A fetch implementation is required")
  if (!Number.isFinite(timeoutMs) || timeoutMs <= 0) throw new TypeError("timeoutMs must be positive")

  let generation = 0
  let disposed = false
  let initialized = false
  let hydrated = false
  let tokens = null
  let csrf = null
  let initialization = null
  let refreshing = null
  let signingIn = null
  let waitingLogin = null
  let signingOut = null
  let binding = null
  let bindingExchange = false
  let csrfRefresh = null
  let passkeyPrompt = null
  let credentialRevision = 0
  let refreshUncertain = false
  let storageTail = Promise.resolve()
  let snapshot = Object.freeze({ status: "unknown", user: null, error: null, expiresAt: null })
  const listeners = new Set()
  const sessionListeners = new Set()
  const controllers = new Set()

  function active() {
    if (disposed) throw new AuthError("Authentication client has been disposed", { code: "DISPOSED" })
  }

  function current(epoch) {
    active()
    if (epoch !== generation) throw new AuthError("The authentication session changed during this operation", { code: "SESSION_CHANGED" })
  }

  function emit(update) {
    snapshot = Object.freeze({ ...snapshot, ...update })
    for (const listener of listeners) {
      try { listener(snapshot) } catch { /* One subscriber must not prevent session cleanup. */ }
    }
    notifySession()
  }

  function getSessionContext() {
    const id = snapshot.user?.user_id ?? snapshot.user?.id
    const family = snapshot.user?.app_session
    return Object.freeze({
      baseURL: base.href, mode, generation,
      accountId: id == null ? null : String(id).trim(),
      appSessionId: typeof family?.id === "string" ? family.id : null,
      clientId: typeof family?.client_id === "string" ? family.client_id : null,
      status: snapshot.status,
    })
  }

  function notifySession() {
    const context = getSessionContext()
    for (const listener of sessionListeners) {
      try { listener(context) } catch { /* Session cleanup must reach every subscriber. */ }
    }
  }

  function advance(preservePasskey = false) {
    active()
    if (!preservePasskey) passkeyPrompt?.abort()
    generation++
    for (const controller of controllers) controller.abort()
    controllers.clear()
    initialization = null
    refreshing = null
    csrfRefresh = null
    notifySession()
    return generation
  }

  function store(operation, epoch) {
    const pending = storageTail.catch(() => {}).then(async () => {
      current(epoch)
      try { await operation() } catch (cause) {
        throw new AuthError("Secure credential storage is unavailable", { code: "TOKEN_STORAGE_FAILED", cause })
      }
      current(epoch)
    })
    storageTail = pending.catch(() => {})
    return pending
  }

  async function hydrate(epoch) {
    if (mode !== "bearer" || hydrated) return
    let loaded
    await store(async () => { loaded = await tokenStore.load() }, epoch)
    current(epoch)
    tokens = loaded == null ? null : tokenPair(loaded, true)
    refreshUncertain = tokens?.refresh_pending === true
    hydrated = true
  }

  async function persistTokens(pair, epoch) {
    const verify = !!(pair.app_session || pair.refresh_pending || tokens?.app_session || tokens?.refresh_pending || clientId)
    if (verify && tokenStore.supportsSessionJournal !== true) throw new AuthError("This protected store needs app-session and refresh-journal support", { code: "TOKEN_STORAGE_UNSUPPORTED" })
    await store(async () => {
      await tokenStore.save(pair)
      if (verify) {
        const restored = tokenPair(await tokenStore.load(), true)
        if (JSON.stringify(restored) !== JSON.stringify(pair)) throw new Error("The protected store did not retain the complete session and refresh journal")
      }
    }, epoch)
  }

  function uncertainRefresh() {
    return new AuthError("Session renewal could not be confirmed; sign in to Farm again", { code: "SESSION_REAUTHENTICATION_REQUIRED" })
  }

  function sessionInfo(response, epoch) {
    current(epoch)
    const nextCsrf = response.headers.get("x-csrf-token")
    if (mode === "cookie" && nextCsrf) csrf = nextCsrf
    const expiry = response.headers.get("x-session-expires")
    if (expiry) {
      const date = new Date(Number(expiry) * 1000)
      if (Number.isFinite(date.getTime())) emit({ expiresAt: date.toISOString() })
    }
  }

  async function send(path, options = {}, epoch = generation) {
    current(epoch)
    const requestTimeout = options.timeoutMs ?? timeoutMs
    if (!Number.isFinite(requestTimeout) || requestTimeout <= 0) throw new TypeError("timeoutMs must be positive")
    const relative = safePath(path)
    const endpoint = relative.split("?")[0]
    const url = new URL(relative, base)
    if (url.origin !== base.origin || !url.pathname.startsWith(base.pathname)) throw new AuthError("API path escapes configured base", { code: "INVALID_PATH" })
    const method = (options.method || "GET").toUpperCase()
    const headers = new Headers(options.headers)
    // Callers cannot accidentally replace credentials or route them elsewhere.
    for (const name of ["authorization", "x-refresh-token", "x-csrf-token", "x-client-type", "x-api-key", "cookie"]) headers.delete(name)
    if (mode === "bearer") {
      headers.set("X-Client-Type", "electron")
      if (!options.skipAuth && tokens?.access_token) headers.set("Authorization", `Bearer ${tokens.access_token}`)
      if ((endpoint === "auth/refresh" || endpoint === "auth/logout") && tokens?.refresh_token) headers.set("X-Refresh-Token", tokens.refresh_token)
    } else if (!READ_METHODS.has(method) && csrf) {
      headers.set("X-CSRF-Token", csrf)
    }
    let body = options.body
    if (body != null && typeof body === "object" && !(body instanceof ArrayBuffer) && !ArrayBuffer.isView(body) && !(typeof Blob !== "undefined" && body instanceof Blob) && !(typeof FormData !== "undefined" && body instanceof FormData) && !(body instanceof URLSearchParams) && !(typeof ReadableStream !== "undefined" && body instanceof ReadableStream)) {
      body = JSON.stringify(body)
      if (!headers.has("content-type")) headers.set("Content-Type", "application/json")
    }
    const controller = new AbortController()
    controllers.add(controller)
    let timedOut = false
    const abort = () => controller.abort(options.signal?.reason)
    if (options.signal?.aborted) abort()
    else options.signal?.addEventListener("abort", abort, { once: true })
    const timeout = setTimeout(() => { timedOut = true; controller.abort() }, requestTimeout)
    try {
      const response = await fetcher(url.href, {
        method, headers, body, signal: controller.signal,
        credentials: mode === "cookie" ? "include" : "omit",
        redirect: "error", cache: "no-store"
      })
      current(epoch)
      if (!response.ok) {
        let payload
        try { payload = await response.json() } catch { payload = null }
        current(epoch)
        const retry = response.headers.get("retry-after")
        const parsedRetry = retry == null ? undefined : /^\d+$/.test(retry) ? Number(retry) : Math.max(0, Math.ceil((Date.parse(retry) - Date.now()) / 1000))
        const details = payload?.error && typeof payload.error === "object" ? payload.error : payload
        throw new AuthError(typeof details?.message === "string" ? details.message : typeof payload?.error === "string" ? payload.error : `Request failed (${response.status})`, {
          status: response.status,
          code: typeof details?.code === "string" ? details.code : typeof payload?.error === "string" ? payload.error : "HTTP_ERROR",
          requestId: typeof payload?.request_id === "string" ? payload.request_id : undefined,
          retryAfter: Number.isFinite(parsedRetry) ? parsedRetry : undefined
        })
      }
      sessionInfo(response, epoch)
      if (options.responseType === "response") return response
      if (response.status === 204 || method === "HEAD") return null
      let payload
      try { payload = await response.json() } catch (cause) {
        throw new AuthError("The server returned invalid JSON", { code: "INVALID_RESPONSE", status: response.status, cause })
      }
      current(epoch)
      if (payload?.success === false) throw new AuthError(payload.message || "The server rejected the request", { code: payload.error || "REQUEST_FAILED", status: response.status })
      return payload
    } catch (error) {
      current(epoch)
      if (error instanceof AuthError) throw error
      if (timedOut) throw new AuthError("The request timed out", { code: "TIMEOUT", cause: error })
      if (options.signal?.aborted) throw new AuthError("The request was cancelled", { code: "ABORTED", cause: error })
      throw new AuthError("Unable to connect to the server", { code: "NETWORK_ERROR", cause: error })
    } finally {
      clearTimeout(timeout)
      controllers.delete(controller)
      options.signal?.removeEventListener("abort", abort)
    }
  }

  async function clearSession() {
    return resetSession(advance())
  }

  async function resetSession(epoch) {
    tokens = null
    csrf = null
    initialized = true
    hydrated = true
    refreshUncertain = false
    emit({ status: "anonymous", user: null, error: null, expiresAt: null })
    if (mode === "bearer") await store(() => tokenStore.clear(), epoch)
  }

  async function accept(payload, epoch, setUser) {
    current(epoch)
    const data = unwrap(payload)
    if (!data || typeof data !== "object") throw new AuthError("The server returned an invalid authentication response", { code: "INVALID_RESPONSE" })
    if (mode === "bearer") {
      const pair = tokenPair(data)
      if (!pair) throw new AuthError("The server did not return credentials", { code: "INVALID_RESPONSE" })
      if (!setUser && tokens?.app_session && (pair.app_session?.id !== tokens.app_session.id || pair.app_session?.client_id !== tokens.app_session.client_id)) throw new AuthError("Session renewal changed the bound app session", { code: "INVALID_RESPONSE" })
      await persistTokens(pair, epoch)
      current(epoch)
      tokens = pair
      hydrated = true
    }
    const clean = sanitized(data)
    const expiry = data.expires_at || data.session_expires
    const update = { error: null }
    if (typeof expiry === "string") update.expiresAt = expiry
    if (setUser) Object.assign(update, { status: "authenticated", user: clean })
    credentialRevision++
    refreshUncertain = false
    emit(update)
    return clean
  }

  async function csrfToken(epoch, bootstrap = false) {
    if (mode !== "cookie" || !csrfEnabled) return null
    const payload = await send(bootstrap ? "auth/refresh/csrf" : "security/csrf/token", { method: "GET" }, epoch)
    current(epoch)
    const value = unwrap(payload)?.token || csrf
    if (typeof value !== "string" || !value) throw new AuthError("The server did not return a CSRF token", { code: "INVALID_RESPONSE" })
    csrf = value
    return csrf
  }

  function refresh() {
    active()
    if (!refreshEnabled) return Promise.reject(new AuthError("This server does not support session refresh", { code: "REFRESH_UNSUPPORTED" }))
    if (refreshing) return refreshing
    if (signingOut) return Promise.reject(new AuthError("Logout is in progress", { code: "SESSION_CHANGED" }))
    // A successful login already supplies fresh credentials. Do not rotate the
    // previous account's session concurrently with the new login.
    if (signingIn) return signingIn
    if (bindingExchange) return binding
    if (refreshUncertain) return Promise.reject(uncertainRefresh())
    const epoch = generation
    let rotationStarted = false
    let journaled = false
    const pending = (async () => {
      try {
        await hydrate(epoch)
        current(epoch)
        if (refreshUncertain) throw uncertainRefresh()
        if (mode === "cookie") await csrfToken(epoch, true)
        if (mode === "bearer" && tokens && (tokens.app_session || getSessionContext().appSessionId || clientId)) {
          // Write-ahead marker and token pair are one protected record. A store
          // that silently drops metadata must fail before any rotating request.
          refreshUncertain = true
          const pendingPair = { ...tokens, refresh_pending: true }
          await persistTokens(pendingPair, epoch)
          current(epoch)
          tokens = pendingPair
          journaled = true
        }
        rotationStarted = true
        const payload = await send("auth/refresh", { method: "POST" }, epoch)
        return await accept(payload, epoch, false)
      } catch (error) {
        if (epoch === generation && !disposed) {
          if (error.status === 401) {
            const waiting = waitingLogin
            if (waiting?.refresh === pending && waiting.epoch === epoch) {
              // A deliberate new sign-in can replace this expired session.
              // Keep a generation barrier for every other old request, while
              // advancing only the attempt waiting for this exact refresh.
              const nextEpoch = advance(true)
              waiting.epoch = nextEpoch
              await resetSession(nextEpoch)
            } else await clearSession()
          } else {
            // A bound rotating refresh may already have been consumed even when
            // the response or durable store failed. Retain credentials for
            // logout, but never blindly submit the same refresh again.
            const boundOrRestoring = getSessionContext().appSessionId || (mode === "bearer" && snapshot.status === "unknown")
            if (rotationStarted && boundOrRestoring && (error.status === undefined || error.status >= 500)) refreshUncertain = true
            if (journaled && error.status === 429) {
              // The rate limiter rejected this request before refresh admission.
              // Other failures may have happened after the token was consumed.
              const retained = { ...tokens }
              delete retained.refresh_pending
              await persistTokens(retained, epoch)
              current(epoch)
              tokens = retained
              refreshUncertain = false
            }
            emit({ error: refreshUncertain ? uncertainRefresh() : error })
          }
        }
        throw error
      }
    })()
    refreshing = pending
    void pending.finally(() => { if (refreshing === pending) refreshing = null }).catch(() => {})
    return pending
  }

  function refreshCsrf() {
    active()
    if (mode !== "cookie" || !csrfEnabled) return Promise.resolve(null)
    if (signingOut) return Promise.reject(new AuthError("Logout is in progress", { code: "SESSION_CHANGED" }))
    if (signingIn) return signingIn.then(() => refreshCsrf())
    if (csrfRefresh) return csrfRefresh
    const epoch = generation
    const pending = (async () => {
      try { return await csrfToken(epoch) } catch (error) {
        if (error.status !== 401) throw error
        await refresh()
        return csrfToken(epoch)
      }
    })()
    csrfRefresh = pending
    void pending.finally(() => { if (csrfRefresh === pending) csrfRefresh = null }).catch(() => {})
    return pending
  }

  async function authenticatedRequest(path, options, epoch) {
    const endpoint = safePath(path).split("?")[0]
    const protect = !options.skipAuth && !BOOTSTRAP.has(endpoint)
    const needsCsrf = csrfEnabled && mode === "cookie" && !options.skipAuth && !READ_METHODS.has((options.method || "GET").toUpperCase()) && endpoint !== "auth/login"
    if (needsCsrf && !csrf) await refreshCsrf()
    let retriedAuth = false
    let retriedCsrf = false
    for (;;) {
      current(epoch)
      const sentRevision = credentialRevision
      try { return await send(path, options, epoch) } catch (error) {
        if (error.status === 401 && protect) {
          if (retriedAuth || !refreshEnabled) {
            await clearSession()
            throw error
          }
          retriedAuth = true
          // A concurrent request may already have renewed the credential while
          // this request's original 401 was still travelling back to us.
          if (sentRevision === credentialRevision) await refresh()
          continue
        }
        if (error.status === 403 && needsCsrf && CSRF_ERRORS.has(error.code) && !retriedCsrf) {
          retriedCsrf = true
          await refreshCsrf()
          continue
        }
        throw error
      }
    }
  }

  function initialize() {
    active()
    if (signingIn) return signingIn
    if (signingOut) return Promise.reject(new AuthError("Logout is in progress", { code: "SESSION_CHANGED" }))
    if (refreshUncertain) return refreshing ? refreshing.then(() => initialize()) : Promise.reject(uncertainRefresh())
    if (initialization) return initialization
    if (initialized) return Promise.resolve(snapshot.user)
    const epoch = generation
    const pending = (async () => {
      try {
        await hydrate(epoch)
        current(epoch)
        if (refreshUncertain) throw uncertainRefresh()
        if (mode === "bearer" && !tokens) {
          initialized = true
          emit({ status: "anonymous", user: null, error: null, expiresAt: null })
          return null
        }
        const payload = await authenticatedRequest("auth/me", { method: "GET" }, epoch)
        current(epoch)
        const user = sanitized(unwrap(payload))
        if (!user || typeof user !== "object") throw new AuthError("The server did not return a user", { code: "INVALID_RESPONSE" })
        if (mode === "bearer" && user.app_session && !tokens?.app_session) {
          const boundPair = tokenPair({ ...tokens, app_session: user.app_session })
          await persistTokens(boundPair, epoch)
          current(epoch)
          tokens = boundPair
        }
        initialized = true
        emit({ status: "authenticated", user, error: null })
        return user
      } catch (error) {
        if (error.status === 401 && !disposed) {
          if (epoch === generation) await clearSession()
          return null
        }
        if (epoch === generation && !disposed) emit({ status: "unknown", user: null, error })
        throw error
      }
    })()
    initialization = pending
    void pending.finally(() => { if (initialization === pending) initialization = null }).catch(() => {})
    return pending
  }

  function login(email, password) {
    active()
    if (signingOut || signingIn || binding) return Promise.reject(new AuthError("Another sign-in or logout is in progress", { code: "SESSION_CHANGED" }))
    if (typeof email !== "string" || typeof password !== "string" || !email.trim() || !password) return Promise.reject(new AuthError("Email and password are required", { code: "INVALID_CREDENTIALS" }))
    const previousRefresh = refreshing
    const attempt = { refresh: previousRefresh, epoch: generation }
    if (previousRefresh) waitingLogin = attempt
    const pending = (async () => {
      if (previousRefresh) {
        try { await previousRefresh } catch { /* Login can replace an expired session. */ }
        finally { if (waitingLogin === attempt) waitingLogin = null }
      }
      current(attempt.epoch)
      const epoch = advance()
      csrf = null
      try {
        const payload = await send("auth/login", { method: "POST", body: { email: email.trim(), password, remember_me: true, ...(clientId ? { client_id: clientId } : {}) }, skipAuth: true }, epoch)
        const user = await accept(payload, epoch, true)
        initialized = true
        return user
      } catch (error) {
        if (epoch === generation && !disposed) emit({ error })
        throw error
      }
    })()
    signingIn = pending
    void pending.finally(() => { if (signingIn === pending) signingIn = null }).catch(() => {})
    return pending
  }

  function loginWithPasskey(options = {}) {
    active()
    if (!options || typeof options !== "object" || (options.preferImmediatelyAvailableCredentials !== undefined && typeof options.preferImmediatelyAvailableCredentials !== "boolean")) return Promise.reject(new AuthError("Invalid passkey options", { code: "INVALID_REQUEST" }))
    const automatic = options.preferImmediatelyAvailableCredentials === true
    if (signingOut || signingIn || binding) return Promise.reject(new AuthError("Another sign-in or logout is in progress", { code: "SESSION_CHANGED" }))
    if (!passkey) return Promise.reject(new AuthError("Passkey sign-in is not available in this app", { code: "PASSKEY_UNSUPPORTED" }))
    const previousRefresh = refreshing
    const attempt = { refresh: previousRefresh, epoch: generation }
    if (previousRefresh) waitingLogin = attempt
    const controller = new AbortController()
    passkeyPrompt = controller
    // Start within the button gesture. Browser popup creation must happen before
    // awaiting an outstanding refresh; exchanging the grant still waits for it.
    let ceremonyResult, onAbort
    const cancelled = new Promise((_, reject) => {
      onAbort = () => reject(new AuthError("Passkey sign-in was cancelled", { code: "PASSKEY_CANCELLED" }))
      controller.signal.addEventListener("abort", onAbort, { once: true })
    })
    try { ceremonyResult = Promise.resolve(passkey({ signal: controller.signal, preferImmediatelyAvailableCredentials: automatic })) }
    catch (error) { ceremonyResult = Promise.reject(error) }
    // Attach both branches even if a transport throws synchronously, so later
    // disposal cannot leave the cancellation promise without a rejection handler.
    const ceremony = Promise.race([ceremonyResult, cancelled])
    void ceremony.catch(() => {})
    const pending = (async () => {
      if (previousRefresh) {
        try { await previousRefresh } catch { /* A new sign-in can replace an expired session. */ }
        finally { if (waitingLogin === attempt) waitingLogin = null }
      }
      current(attempt.epoch)
      const epoch = advance(true)
      csrf = null
      try {
        const handoff = await ceremony
        current(epoch)
        if (controller.signal.aborted) throw new AuthError("Passkey sign-in was cancelled", { code: "PASSKEY_CANCELLED" })
        if (!handoff || ["code", "code_verifier", "client_id", "redirect_uri"].some(key => typeof handoff[key] !== "string" || !handoff[key])) {
          throw new AuthError("The passkey response was incomplete", { code: "INVALID_RESPONSE" })
        }
        // Once exchange starts, logout waits for the newly issued credentials
        // instead of aborting a server transaction whose response may be lost.
        if (passkeyPrompt === controller) passkeyPrompt = null
        const body = Object.fromEntries(["code", "code_verifier", "client_id", "redirect_uri"].map(key => [key, handoff[key]]))
        if (clientId && handoff.client_id !== clientId) throw new AuthError("Passkey handoff belongs to a different app", { code: "INVALID_RESPONSE" })
        const payload = await send("auth/passkeys/exchange", { method: "POST", body, skipAuth: true,
          ...(clientId ? { headers: { "X-Farm-Session-Binding": "farm.service-access/1" } } : {}),
        }, epoch)
        const user = await accept(payload, epoch, true)
        initialized = true
        return user
      } catch (cause) {
        const error = cause instanceof AuthError ? cause : new AuthError(
          cause?.message || "Passkey sign-in failed", { code: controller.signal.aborted ? "PASSKEY_CANCELLED" : cause?.code || "PASSKEY_FAILED", cause })
        if (epoch === generation && !disposed && !automatic && error.code !== "PASSKEY_CANCELLED") emit({ error })
        throw error
      } finally {
        if (passkeyPrompt === controller) passkeyPrompt = null
      }
    })()
    signingIn = pending
    void pending.finally(() => {
      controller.signal.removeEventListener("abort", onAbort)
      if (passkeyPrompt === controller) passkeyPrompt = null
      if (signingIn === pending) signingIn = null
    }).catch(() => {})
    return pending
  }

  function bindAppSession({ clientId: bindingClient = clientId, redirectUri } = {}) {
    active()
    if (mode !== "bearer") return Promise.reject(new AuthError("App-session binding requires native bearer transport", { code: "app_session_binding_required", status: 409 }))
    if (tokenStore.supportsSessionJournal !== true) return Promise.reject(new AuthError("App-session binding requires protected refresh-journal storage", { code: "TOKEN_STORAGE_UNSUPPORTED" }))
    if (typeof bindingClient !== "string" || !/^[a-z0-9][a-z0-9._-]{0,63}$/.test(bindingClient) || typeof redirectUri !== "string" || !redirectUri || /[\u0000-\u0020]/.test(redirectUri)) return Promise.reject(new AuthError("A registered client and exact callback are required", { code: "invalid_client", status: 400 }))
    if (binding || signingIn || signingOut) return Promise.reject(new AuthError("Another sign-in or logout is in progress", { code: "SESSION_CHANGED" }))
    if (!globalThis.crypto?.subtle || !globalThis.crypto?.getRandomValues) return Promise.reject(new AuthError("Secure randomness is unavailable", { code: "CRYPTO_UNAVAILABLE" }))
    const started = generation
    const pending = (async () => {
      await initialize()
      current(started)
      if (snapshot.status !== "authenticated") throw new AuthError("Sign in to Farm before binding this app", { code: "invalid_token", status: 401 })
      // Restore/rotate before issuing a single-use authorization code. Neither
      // authorize nor exchange is automatically replayed after an ambiguous failure.
      if (refreshEnabled) await refresh()
      current(started)
      const epoch = advance()
      bindingExchange = true
      const encode = bytes => btoa(String.fromCharCode(...bytes)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "")
      const verifier = encode(crypto.getRandomValues(new Uint8Array(32)))
      const state = encode(crypto.getRandomValues(new Uint8Array(32)))
      const challenge = encode(new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(verifier))))
      current(epoch)
      const grant = unwrap(await send("auth/app-session/authorize", { method: "POST", body: {
        client_id: bindingClient, redirect_uri: redirectUri, state,
        code_challenge_method: "S256", code_challenge: challenge,
      } }, epoch))
      if (!grant || typeof grant.code !== "string" || !grant.code || grant.client_id !== bindingClient || grant.redirect_uri !== redirectUri || grant.state !== state) throw new AuthError("The app-session authorization response did not match this request", { code: "INVALID_RESPONSE" })
      const payload = await send("auth/app-session/exchange", { method: "POST", skipAuth: true, body: {
        code: grant.code, client_id: bindingClient, redirect_uri: redirectUri, state, code_verifier: verifier,
      } }, epoch)
      const data = unwrap(payload)
      if (data?.app_session?.client_id !== bindingClient || typeof data.app_session.id !== "string" || !data.app_session.id || String(data.user_id ?? data.id).trim() !== getSessionContext().accountId) throw new AuthError("The bound session identity did not match this account", { code: "INVALID_RESPONSE" })
      const user = await accept(payload, epoch, true)
      initialized = true
      return user
    })()
    binding = pending
    void pending.finally(() => { if (binding === pending) { binding = null; bindingExchange = false } }).catch(() => {})
    return pending
  }

  function logout() {
    active()
    if (signingOut) return signingOut
    passkeyPrompt?.abort()
    const priorOperations = [signingIn, refreshing, initialization, binding].filter(Boolean)
    const pending = (async () => {
      // Do not abort a server-side rotation and then revoke its stale input.
      // Finish receiving/persisting any already-issued credentials first.
      await Promise.allSettled(priorOperations)
      const epoch = advance()
      try {
        await hydrate(epoch)
        if (mode === "cookie" && csrfEnabled) {
          try { await csrfToken(epoch, true) } catch (error) {
            if (error.status !== 401) throw error
            // Access-only legacy sessions can still obtain their normal CSRF token.
            try { await csrfToken(epoch) } catch (fallback) {
              if (fallback.status !== 401) throw fallback
            }
          }
        }
        // Logout is idempotent even when neither credential remains valid. Do
        // not make it depend on another authenticated fetch in that case.
        try { await send("auth/logout", { method: "POST" }, epoch) } catch (error) {
          if (!csrfEnabled || mode !== "cookie" || error.status !== 403 || !CSRF_ERRORS.has(error.code)) throw error
          await csrfToken(epoch, true)
          await send("auth/logout", { method: "POST" }, epoch)
        }
        current(epoch)
        await clearSession()
      } catch (error) {
        if (epoch === generation && !disposed) emit({ error })
        throw error
      }
    })()
    signingOut = pending
    void pending.finally(() => { if (signingOut === pending) signingOut = null }).catch(() => {})
    return pending
  }

  async function request(path, options = {}) {
    active()
    const endpoint = safePath(path).split("?")[0]
    if (endpoint === "auth/refresh" && mode === "bearer") await hydrate(generation)
    if (endpoint === "auth/refresh" && mode === "bearer" && (tokens?.app_session || clientId || refreshUncertain)) throw new AuthError("Use refresh() to rotate a bound session safely", { code: "INVALID_REQUEST" })
    if (signingOut && !options.skipAuth) throw new AuthError("Logout is in progress", { code: "SESSION_CHANGED" })
    if (binding && !options.skipAuth) await binding
    if (!options.skipAuth && !BOOTSTRAP.has(endpoint)) await initialize()
    const epoch = generation
    return authenticatedRequest(path, options, epoch)
  }

  async function getCurrentUser() {
    active()
    if (signingOut) throw new AuthError("Logout is in progress", { code: "SESSION_CHANGED" })
    if (signingIn) await signingIn
    if (binding) await binding
    if (refreshUncertain) {
      if (refreshing) await refreshing
      if (refreshUncertain) throw uncertainRefresh()
    }
    if (!initialized) return initialize()
    const epoch = generation
    const payload = await authenticatedRequest("auth/me", { method: "GET" }, epoch)
    current(epoch)
    const user = sanitized(unwrap(payload))
    if (!user || typeof user !== "object") throw new AuthError("The server did not return a user", { code: "INVALID_RESPONSE" })
    emit({ status: "authenticated", user, error: null })
    return user
  }

  return Object.freeze({
    initialize, login, loginWithPasskey, bindAppSession, logout, refresh, getCurrentUser, request, clearSession, refreshCsrf,
    getSessionContext,
    subscribeSession(listener) {
      active()
      if (typeof listener !== "function") throw new TypeError("listener must be a function")
      sessionListeners.add(listener)
      return () => sessionListeners.delete(listener)
    },
    getCsrfToken: () => csrf,
    getState: () => snapshot,
    subscribe(listener) {
      active()
      if (typeof listener !== "function") throw new TypeError("listener must be a function")
      listeners.add(listener)
      return () => listeners.delete(listener)
    },
    dispose() {
      if (disposed) return
      advance()
      disposed = true
      tokens = null
      csrf = null
      listeners.clear()
      snapshot = Object.freeze({ status: "unknown", user: null, error: null, expiresAt: null })
      notifySession()
      sessionListeners.clear()
    }
  })
}
