export interface PasskeyHandoff {
  code: string;
  code_verifier: string;
  client_id: string;
  redirect_uri: string;
}
export type PasskeyResult<T = undefined> =
  | { ok: true; data?: T }
  | { ok: false; code: string; error: string };
export interface DesktopPasskeyOptions {
  clientId: "morph" | "flooder" | "manager" | "floodgate";
  BrowserWindow: new (options: object) => any;
  getWindow: () => any;
  nativePath: string;
  preloadPath: string;
  timeoutMs?: number;
}
export interface DesktopPasskeys {
  /** Suppress automatic sign-in after an explicit logout, including renderer reloads. */
  suppressAutomaticLogin(): void;
  login(options?: {
    preferImmediatelyAvailableCredentials?: boolean;
  }): Promise<PasskeyResult<PasskeyHandoff>>;
  manage(): Promise<PasskeyResult>;
  cancel(): PasskeyResult;
  dispose(): void;
}
export function createElectronPasskeys(
  options: DesktopPasskeyOptions,
): DesktopPasskeys;
export function registerElectronPasskeyHandlers(
  options: DesktopPasskeyOptions & {
    ipcMain: any;
    app: any;
    isTrustedSender: (event: any) => boolean;
  },
): DesktopPasskeys;
