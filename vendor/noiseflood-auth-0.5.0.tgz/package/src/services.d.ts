import type { AuthClient } from './index.js'

export interface ServiceMetadata {
  readonly service_id: string
  readonly audience: string
  readonly display_name: string
  readonly base_url: string
  readonly auth_contract: string
  readonly enabled: boolean
  readonly scopes: readonly string[]
  readonly available_scopes: readonly string[]
  readonly access: 'available' | 'denied' | 'disabled'
  readonly capabilities_path: string | null
}

export interface ServiceRequestOptions {
  method?: string
  body?: BodyInit | Record<string, unknown> | readonly unknown[] | null
  headers?: HeadersInit
  signal?: AbortSignal
  timeoutMs?: number
  /** Responses are buffered and checked against the pinned session before return. */
  responseType?: 'json' | 'text' | 'blob' | 'arrayBuffer'
}

export interface ServiceConnection {
  readonly serviceId: string
  readonly baseURL: string
  readonly audience: string
  readonly issuer: string
  readonly accountId: string
  readonly appSessionId: string
  readonly generation: number
  readonly scopes: readonly string[]
  /** Check immediately before committing a result to the still-active document. */
  assertCurrent(): void
  request(path: string, options: ServiceRequestOptions & { responseType: 'text' }): Promise<string | null>
  request(path: string, options: ServiceRequestOptions & { responseType: 'blob' }): Promise<Blob | null>
  request(path: string, options: ServiceRequestOptions & { responseType: 'arrayBuffer' }): Promise<ArrayBuffer | null>
  request<T = unknown>(path: string, options?: ServiceRequestOptions): Promise<T>
  dispose(): void
}

export interface ServiceClient {
  discover(options?: { signal?: AbortSignal }): Promise<readonly ServiceMetadata[]>
  connect(serviceId: string, options?: { scopes?: readonly string[]; signal?: AbortSignal }): Promise<ServiceConnection>
  dispose(): void
}

export function createServiceClient(options: {
  auth: AuthClient
  /** Exact administrator-pinned issuer; never take this value from a token. */
  issuer: string
  fetch?: typeof globalThis.fetch
  timeoutMs?: number
  /** Test clock in milliseconds. Defaults to Date.now. */
  now?: () => number
}): ServiceClient
