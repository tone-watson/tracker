/** One optional native passkey attempt per application load. Construct once,
 * mount with the authentication UI, and suppress before any explicit auth action. */
export function createDesktopPasskeyStartup({
  initialize, getState, login, isSupported,
  document = globalThis.document, window = globalThis.window,
}) {
  let handled = false
  const mounts = new Set()

  function suppress() {
    handled = true
    for (const stop of [...mounts]) stop()
  }

  function mount() {
    if (handled || !document || !window || !isSupported()) return () => {}
    let active = true
    const stop = () => {
      active = false
      document.removeEventListener("visibilitychange", attempt)
      window.removeEventListener("focus", attempt)
      mounts.delete(stop)
    }
    const attempt = () => {
      if (!active || handled) return
      if (getState().status !== "anonymous") { suppress(); return }
      if (document.hidden || document.hasFocus?.() !== true) return
      suppress()
      // This transport must request only immediately available credentials.
      // Unsupported providers, missing keys and cancellation stay quiet.
      try { void Promise.resolve(login({ preferImmediatelyAvailableCredentials: true })).catch(() => {}) }
      catch { /* Manual sign-in remains available. */ }
    }
    mounts.add(stop)
    void Promise.resolve().then(() => {
      if (active && !handled) return initialize()
    }).then(() => {
      if (!active || handled) return
      if (getState().status !== "anonymous") { suppress(); return }
      document.addEventListener("visibilitychange", attempt)
      window.addEventListener("focus", attempt)
      attempt()
    }).catch(stop)
    return stop
  }

  return { mount, suppress }
}
