"use strict";
const { contextBridge, ipcRenderer } = require("electron");

// This preload belongs only to the fixed identity modal, never an application renderer.
contextBridge.exposeInMainWorld("farmPasskeys", {
  get: (publicKey) => ipcRenderer.invoke("farm-passkeys:get", publicKey),
  create: (publicKey) => ipcRenderer.invoke("farm-passkeys:create", publicKey),
  complete: (result) => ipcRenderer.invoke("farm-passkeys:complete", result),
  ready: () => ipcRenderer.invoke("farm-passkeys:ready"),
  fail: (result) => ipcRenderer.invoke("farm-passkeys:fail", result),
});
